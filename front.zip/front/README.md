Altesse Frontend
=================

# Getting Started
### altesse-front 
Project has been built on [AWS](http://altesse.io.s3-website.eu-west-3.amazonaws.com)

## Installation
1. Get a clone on the **front** repo url - git clone git@bitbucket.org:altesseio/front.git
2. Change your working directory to **front**
3. You'll need to install all node modules!. run ***npm install***
4. run ***npm run serve***  to start the server and the application should run on the browser on http://localhost:8080/.

## Folder structure
src/
├── assets/
├── data/
├── locales/
├── models/
├── plugins/
├── router/
├── services/
├── store/
├── styles/
└── views/
  │── App.vue   
  │── main.js

For this project we use VueJs frameworks and for state management we  use Vuex. 
1. *assets* folder includes all images(png, jpeg, svg).
2. *data* all json files should place here.
3. *locale* we have maintain localization in this application, localization json file place here.
4. *plugins* plugins uses for specific packages place here.
5. *models* model classes include.
6. *router* vue-router routes included here.
7. *services* all service classes place here.
8. *store* vuex store modules should place here.
9. *styles* all css place here
10. *views* all pages and components resides in this folder. There are child folder for each pages and components

# src/main.js
This is the main JavaScript files that drive our app. We first import the Vue library and the App component from App.vue. Next, we create the Vue instance, by assigning it to the DOM element identified by #app, which we defined in index.html, and we tell it to use the App component.
```
new Vue({router, store, vuetify, i18n, render: h => h(App)}).$mount('#app');
```

Make XMLHttpRequests from the browser, we are using **axios**. Base url place on the ***.env.development***
```
axios.defaults.baseURL = process.env.VUE_APP_URL;
```

# Naming conventions
Here are a few conventions coming from the Vue.js official styleguide that you need to structure well our project:
1. Component names should always be multi-word, except for root “App” components. Use “UserCard” or “ProfileCard” instead of “Card” for example.
2. Each component should be in its own file.
3. Filenames of single-file components should either be always PascalCase or always kebab-case. Use “UserCard.vue” or “user-card.vue”.
4. Components that are only used once per page should begin with the prefix “The”, to denote that there can be only one. For example for a navbar or a footer you should use “TheNavbar.vue” or “TheFooter.vue”.
5. Child components should include their parent name as a prefix. For example if you would like a “Photo” component used in the “UserCard” you will name it “UserCardPhoto”. It’s for better readability since files in a folder are usually order alphabetically.
6. Always use full name instead of abbreviation in the name of your components. For example don’t use “UDSettings”, use instead “UserDashboardSettings”.

# Styleguide
For styling in this project we use Vuetify package. Most vuetify classes override in our project. We use scss as style sheet language. 
All style should place under ***styles*** folder. Component css should add to ***components*** folder and pages under ***pages*** folder.
When you add new scss file you should import it on ***app.scss*** file.

