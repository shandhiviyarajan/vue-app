import axios from 'axios';
import store from '../store';

class ChatService {
  getChats() {
    return axios.get(
      `/chat/messages/?channel=${store.state.chat.selectedChannelName}&page=${store.state.chat.pageCount}`,
      {
        headers: { Authorization: 'JWT ' + store.state.auth.user_data.access }
      }
    );
  }
}

export default new ChatService();
