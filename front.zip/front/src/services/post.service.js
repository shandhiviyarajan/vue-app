import axios from 'axios';
import store from '../store';

class PostService {
  getPost() {
    return axios.get(
      `posts/?page=${store.state.post.pageCount}&feedwall=${store.state.auth.selectedFeedWall}`,
      {
        headers: { Authorization: 'JWT ' + store.state.auth.user_data.access }
      }
    );
  }

  createPost(post) {
    return axios.post(`posts/`, post, {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }

  updatePost(payload) {
    return axios.patch(`posts/${payload.postId}/`, payload.updatedPost, {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }

  deletePost(postId) {
    return axios.delete(`posts/${postId}`, {
      headers: { Authorization: 'JWT ' + store.state.auth.user_data.access }
    });
  }

  createComment(payload) {
    const { postId, commentData } = payload;
    return axios.post(`posts/${postId}/comments/`, commentData, {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }

  updateComment(payload) {
    const { commentId, updatedComment } = payload;
    return axios.patch(`comments/${commentId}/`, updatedComment, {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }

  loadPreviousComments(payload) {
    const { postId, next } = payload;
    return axios.get(`posts/${postId}/comments/?page=${next}`, {
      headers: { Authorization: 'JWT ' + store.state.auth.user_data.access }
    });
  }

  deleteComment(commentId) {
    return axios.delete(`comments/${commentId}`, {
      headers: { Authorization: 'JWT ' + store.state.auth.user_data.access }
    });
  }

  addLikeToPost(postId) {
    return axios.post(
      `posts/${postId}/likes/`,
      {},
      {
        headers: {
          Authorization: 'JWT ' + store.state.auth.user_data.access
        }
      }
    );
  }

  deleteLikeFromPost(likeId) {
    return axios.delete(`likes/${likeId}/`, {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }

  addLikeToComment(commentId) {
    return axios.post(
      `comments/${commentId}/likes/`,
      {},
      {
        headers: {
          Authorization: 'JWT ' + store.state.auth.user_data.access
        }
      }
    );
  }

  deleteLikeFromComment(likeId) {
    return axios.delete(`likes/${likeId}/`, {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }
}

export default new PostService();
