import axios from 'axios';
import store from '../store';

class AuthService {
  pullUser() {
    return axios.get('auth/users/me/', {
      headers: {
        Authorization: 'JWT ' + store.state.auth.user_data.access
      }
    });
  }
  pullCommu() {
    return axios.get('community/');
  }
  login(user) {
    return axios
      .post('auth/jwt/create', {
        email: user.email,
        password: user.password
      })
  }
  register(user) {
    return axios.post('auth/users/', {
      username: user.username,
      email: user.email,
      password: user.password
    });
  }
}

export default new AuthService();
