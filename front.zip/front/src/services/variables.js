export const API_URL = process.env.VUE_APP_URL;
