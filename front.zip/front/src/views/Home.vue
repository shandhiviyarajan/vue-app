<template>
  <v-content>
    <CreateNewPost v-on:updatePostList="updatePosts" />

    <v-card class="my-6">
      <div class="text-center">
        <img src="/assets/svg/post-leaf.svg" alt />
        <h3 class="mb-3">Connectez vous pour ajouter un post</h3>
        <v-btn class="primary" :ripple="false" depressed>Se connecter</v-btn>
      </div>
    </v-card>

    <v-card class="v-card-tabs">
      <div class="v-card-title">
        <h3>🙋 À propos</h3>
      </div>
      <div class="d-flex">
        <v-tabs v-model="v_tabs">
          <v-tab :ripple="false" @click="preventDefault">
            Sujects
            <span class="count">63</span>
          </v-tab>
          <v-tab :ripple="false" @click="preventDefault">
            Members
            <span class="count">86</span>
          </v-tab>
        </v-tabs>
        <v-menu offset-y>
          <template v-slot:activator="{ on, attrs }">
            <v-btn v-bind="attrs" v-on="on" x-small :ripple="false" depressed text fab>
              Le plus récent &nbsp; &nbsp;
              <i class="fa fa-angle-down"></i>
            </v-btn>
          </template>
          <v-list>
            <v-list-item>Lorem ipsum</v-list-item>
          </v-list>
        </v-menu>
      </div>
    </v-card>

    <v-tabs-items v-model="v_tabs">
      <v-tab-item>
        <PostItem
          v-for="(post, postIndex) in posts"
          :key="postIndex + 'postItem'"
          :post="post"
          @load-post="updatePosts"
        />

        <ScrollLoader
          :loaderMethod="ScrollLoadergetNextPosts"
          :loaderDisable="!haveNextPage"
          :loaderColor="'#3f3e4f'"
          :loaderSize="50"
        />
        <div class="bottom-empty" v-if="!haveNextPage"></div>
      </v-tab-item>
      <v-tab-item>
        <MembersGrid />
      </v-tab-item>
    </v-tabs-items>
  </v-content>
</template>

<script>
import ScrollLoader from './components/plugins/ScrollLoader';
import PostItem from './components/Post/PostItem';
import CreateNewPost from './components/Post/CreateNewPost';
import MembersGrid from './components/members/MembersGrid';

export default {
  name: 'Home',

  components: { ScrollLoader, PostItem, CreateNewPost, MembersGrid },

  data() {
    return {
      v_tabs: null
    };
  },

  computed: {
    loggedIn() {
      return this.$store.state.auth.status.loggedIn;
    },
    user() {
      return this.$store.state.auth.user_data;
    },

    posts() {
      return this.$store.state.post.posts;
    },

    haveNextPage() {
      return this.$store.state.post.haveNextPage;
    },

    pageCount() {
      return this.$store.state.post.pageCount;
    }
  },

  created() {
    this.$store.dispatch('post/getPostList');
  },

  methods: {
    preventDefault(e) {
      e.preventDefault();
    },
    updatePosts() {
      this.$store.dispatch('post/getPostList');
    },

    ScrollLoadergetNextPosts() {
      if (this.posts.length > 0) {
        this.$store.dispatch('post/getPostList');
      }
    }
  }
};
</script>
