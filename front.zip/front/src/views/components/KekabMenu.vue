<template>
  <div>
    <v-menu v-if="true" bottom left>
      <template v-slot:activator="{ on }">
        <v-btn fab text icon depressed :ripple="false" elevation="false" v-on="on" class="btn-dots">
          <v-icon color="#abb0b9">mdi-dots-horizontal</v-icon>
        </v-btn>
      </template>
      <v-list>
        <v-list-item v-for="(item, i) in items" :key="i" @click="itemClickHandler">
          <v-list-item-title :id="item.event">{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

    <!-- <v-btn depressed elevation="false" fab text icon class="btn-pin">
      <v-icon>mdi-pin</v-icon>
    </v-btn>-->
  </div>
</template>

<script>
export default {
  name: 'KebabMenu',

  props: {
    items: Array,
    showMenu: Boolean
  },

  methods: {
    itemClickHandler(event) {
      this.$emit('menu-event-dispatch', event.target.id);
    }
  }
};
</script>
