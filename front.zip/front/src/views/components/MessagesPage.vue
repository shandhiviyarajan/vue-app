t<template>
  <v-row>
    <v-col cols="12">
      <v-content>
        <v-card class="mb-6">
          <div class="d-flex align-center justify-space-between">
            <h4>Messages</h4>
            <div>
              <v-btn depressed fab text :ripple="false">
                <i class="icon-mail-opened"></i>
              </v-btn>
              <v-btn depressed fab text :ripple="false">
                <i class="icon-settings"></i>
              </v-btn>
            </div>
          </div>
        </v-card>
        <v-card class="py-0">
          <v-list class="list-messages">
            <v-list-item>
              <div class="d-flex align-center">
                <v-avatar size="44">
                  <img src="/assets/images/u1.jpg" alt />
                </v-avatar>
                <div>
                  <div class="list-messages__name">FKA Twigs</div>
                  <div class="list-messages__message">a envoyé une photo</div>
                  <div class="list-messages__time">il y’a 8 secondes</div>
                </div>
              </div>

              <v-badge color="primary" dot />
            </v-list-item>

            <v-list-item>
              <div class="d-flex align-center">
                <v-avatar size="44">
                  <img src="/assets/images/u1.jpg" alt />
                </v-avatar>
                <div>
                  <div class="list-messages__name">FKA Twigs</div>
                  <div class="list-messages__message">a envoyé une photo</div>
                  <div class="list-messages__time">il y’a 8 secondes</div>
                </div>
              </div>
              <v-btn depressed fab text :ripple="false">
                <i class="icon-x-mark-rounded"></i>
              </v-btn>
              <v-badge color="primary" dot />
            </v-list-item>

            <v-list-item>
              <div class="d-flex align-center">
                <v-avatar size="44">
                  <img src="/assets/images/u1.jpg" alt />
                </v-avatar>
                <div>
                  <div class="list-messages__name">FKA Twigs</div>
                  <div class="list-messages__message">a envoyé une photo</div>
                  <div class="list-messages__time">il y’a 8 secondes</div>
                </div>
              </div>

              <v-badge color="primary" dot />
            </v-list-item>

            <v-list-item>
              <div class="d-flex align-center">
                <v-avatar size="44">
                  <img src="/assets/images/u1.jpg" alt />
                </v-avatar>
                <div>
                  <div class="list-messages__name">FKA Twigs</div>
                  <div class="list-messages__message">a envoyé une photo</div>
                  <div class="list-messages__time">il y’a 8 secondes</div>
                </div>
              </div>

              <v-badge color="primary" dot />
            </v-list-item>
          </v-list>
        </v-card>
      </v-content>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: 'Messages Page'
};
</script>