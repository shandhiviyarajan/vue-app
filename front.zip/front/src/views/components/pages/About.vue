<template>
  <v-card class="mx-auto mt-10 headline elevation-0" width="200px">
    <v-card-title>{{ $t('sections.about') }}</v-card-title>
  </v-card>
</template>
<script>
export default {
  name: 'About'
};
</script>