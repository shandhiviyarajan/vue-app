<template>
  <div style="margin-bottom: 10px;">
    <div
      v-on:click.prevent="loadPrevousComments"
      class="previous-comments"
    >{{ $t('labels.previous_comments') }}</div>
  </div>
</template>

<script>
export default {
  name: 'PreviousComments',

  methods: {
    loadPrevousComments() {
      this.$emit('load-prevous-comments');
    }
  }
};
</script>

<style scoped>
.previous-comments {
  padding: 10px;
  display: inline-block;
  color: #abb0b9;
  font-size: 11px;
  margin-bottom: 0;
  width: auto;
  text-align: left;
  min-height: 14px;
  cursor: pointer;
}

.previous-comments:hover {
  color: #242c39;
  background-color: #e9edf5;
}
</style>
