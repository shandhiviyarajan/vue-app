<template>
  <div class="comment-area-container">
    <PreviousComments
      @load-prevous-comments="loadPreviousComments"
      v-if="comments.next !== null"
    />
    <FeedComment
      v-for="(comment, commentIndex) in comments.results"
      :key="commentIndex"
      :comment="comment"
      @detele-comment="deleteCommentById"
    />
    <div class="new-comment-container">
      <div class="avatar">
        <v-avatar class size="40">
          <img v-if="user.pp" :src="user.pp" />
          <span v-else>{{ (user.username || '').split('')[0].toUpperCase() }}</span>
        </v-avatar>
      </div>
      <NewPost view="'comment'" :postId="postId" />
    </div>
  </div>
</template>

<script>
import PreviousComments from './PreviousComments';
import FeedComment from './FeedComment';
import NewPost from '../Post/NewPost';

export default {
  name: 'CommentArea',

  props: {
    comments: Object,
    postId: Number
  },

  components: { PreviousComments, FeedComment, NewPost },

  computed: {
    user() {
      return this.$store.state.auth.user_data;
    }
  },

  methods: {
    deleteCommentById(event) {
      this.$store.dispatch('post/deleteComment', {
        postId: this.postId,
        commentId: event
      });
    },

    loadPreviousComments() {
      let nextPageNumber = this.comments.next.slice(
        this.comments.next.length - 1
      );
      this.$store.dispatch('post/loadPreviousComments', {
        postId: this.postId,
        next: nextPageNumber
      });
    }
  }
};
</script>
