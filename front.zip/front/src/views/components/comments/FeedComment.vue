<template>
  <div class="comment-box">
    <div style="display: flex; flex-direction: row; ">
      <Profile :user="comment.user" />
      <Info :createdDate="comment.created_at" />
      <v-spacer></v-spacer>
      <KebabMenu
        v-if="isMenuShow"
        :showMenu="isHovering"
        :items="menuItems"
        @menu-event-dispatch="menuEventHandler"
      />
    </div>
    <div class="comment-body">
      <Feed v-if="!isEditMode" :post="comment" />

      <NewPost
        :viwe="'comment'"
        :isEditMode="isEditMode"
        :data="comment"
        v-if="isEditMode"
        v-on:set-edit-mode="setEditModeHandler"
      />

      <div class="reaction-info-container">
        <Reactions
          :likes="comment.likes"
          @toggle-favourite="toggleFavourite"
          :display="false"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Info from '../Post/Info';
import Profile from '../profile/Profile';
import Reactions from '../Post/Reactions';
import Feed from '../feeds/Feed';
import KebabMenu from '../KekabMenu';
import NewPost from '../Post/NewPost';

export default {
  name: 'FeedComment',

  components: { Profile, Reactions, Feed, KebabMenu, NewPost, Info },

  props: {
    comment: Object,
    isHovering: Boolean
  },

  data() {
    return {
      currentUser: this.comment.user,
      isEditMode: false
    };
  },

  computed: {
    user() {
      return this.$store.state.auth.user_data;
    },

    isMenuShow() {
      if (
        this.user.username === this.currentUser.username &&
        this.user.id === this.currentUser.id
      ) {
        return true;
      }
      return false;
    },

    menuItems() {
      if (this.isMenuShow) {
        return [
          { event: 'edit-comment', title: 'Edit' },
          { event: 'detele-comment', title: 'Delete' }
        ];
      } else {
        return null;
      }
    }
  },

  methods: {
    setEditModeHandler() {
      this.isEditMode = false;
    },

    menuEventHandler(event) {
      switch (event) {
        case 'edit-comment':
          this.isEditMode = true;
          break;
        case 'detele-comment':
          this.$emit('detele-comment', this.comment.id);
          break;
      }
    },

    toggleFavourite(event) {
      if (event.action) {
        this.addFavourite();
      } else {
        this.removeFavourite(event.id);
      }
    },

    addFavourite() {
      this.$store.dispatch('post/addLikeToComment', {
        commentId: this.comment.id,
        postId: this.comment.parent
      });
    },

    removeFavourite(likeId) {
      this.$store.dispatch('post/deleteLikeFromComment', {
        likeId,
        postId: this.post.id,
        commentId: this.comment.id
      });
    }
  }
};
</script>

<style scoped>
.comment-box:hover {
  background-color: #fafafa;
}

.comment-container {
  font-size: 14px;
  margin-left: 63px;
}

.reaction-info-container {
  display: flex;
  align-items: center;
  margin-left: 0px;
}

.comment-body {
  margin-left: 52px;
}
</style>
