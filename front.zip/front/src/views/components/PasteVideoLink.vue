<template>
  <div>
    <input
      v-if="!videoLoaded"
      autocomplete="off"
      @paste.prevent="onPasteHandler($event)"
      class="paste-link"
      v-model="pasteLink"
      placeholder="Paste a link here..."
      type="text"
    />

    <div class="paste-error" v-if="showError">{{ errorMessage }}</div>

    <v-btn v-if="validLink && !videoLoaded" :loading="!videoLoaded" color="secondary"></v-btn>

    <div
      v-if="validLink"
      style=" margin-top: 10px; position: relative; display: flex; border: 1px solid red; width:320px; height: 180px; overflow-y: hidden; "
    >
      <iframe @load="loadYoutube($event)" :height="180" :src="youtubeUrl()" :width="320" />
      <v-btn v-on:click="removeYoutubeLink" class="remove-video-btn" icon color="#abb0b9">
        <v-icon dark>mdi-close-box</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PasteVideoLink',

  data() {
    return {
      videoLoaded: false,
      pasteLink: '',
      showError: false,
      errorMessage: this.$t('messages.error_wrong_video_link'),
      validLink: false,
      videoId: ''
    };
  },

  methods: {
    onPasteHandler($event) {
      let clipboardData =
        $event.clipboardData ||
        $event.originalEvent.clipboardData ||
        window.clipboardData;
      let replacedData = clipboardData.getData('text');
      this.pasteLink = replacedData;
      this.validLink = this.checkValidYoutubeUrl(this.pasteLink);
      this.showError = !this.validLink;
    },

    loadYoutube() {
      this.videoLoaded = true;
    },

    youtubeUrl() {
      return `https://www.youtube.com/embed/${this.videoId}?modestbranding=1&playsinline=0
      &showinfo=0&enablejsapi=1&origin=${window.location.origin}&widgetid=1`;
    },

    removeYoutubeLink() {
      this.validLink = false;
      this.videoId = '';
      this.pasteLink = '';
      this.videoLoaded = false;
    },

    checkValidYoutubeUrl(url) {
      let reg = /^(?:https?:\/\/)?(?:m\.|www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
      if (url.match(reg)) {
        this.validLink = true;
        this.videoId = url.match(reg)[1];
        return true;
      }
      return false;
    }
  }
};
</script>

<style scoped>
.paste-link {
  background-color: #f4f6fa;
  border-radius: 4px;
  box-sizing: border-box;
  width: 100%;
  padding: 10px 10px;
  border-width: 1px;
  border-style: solid;
  border-color: #c8cdd3;
  outline: none;
  font-size: 16px;
}

.paste-error {
  color: #e04247;
  margin-top: 10px;
}

.remove-video-btn {
  position: absolute;
  top: 10px;
  right: 10px;
}
</style>
