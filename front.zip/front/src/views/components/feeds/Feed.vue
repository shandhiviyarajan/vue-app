<template>
  <div class="v-feed">
    <FileMedia v-if="post.file || post.image || post.video" :media="post" />
    <Link v-if="post.link_preview" :link="post.link_preview" />
    <TextContainer
      v-if="post.body"
      :moreStr="this.$t('buttons.show_more')"
      :text="post.body"
      :lessStr="this.$t('buttons.show_less')"
      :maxChars="500"
    />
  </div>
</template>

<script>
import TextContainer from '../TextContainer';
import Link from '../Link';
import FileMedia from '../FileMedia';

export default {
  name: 'Feed',

  components: { TextContainer, Link, FileMedia },

  props: {
    post: Object
  }
};
</script>

<style scoped>
.v-feed {
  display: flex;
  flex-direction: column;
  margin-top: 16px;
  margin-bottom: 12px;
}

.image-container {
  text-align: center;
  margin-bottom: 16px;
}

.v-feed__title {
  margin-bottom: 12px;
  font-weight: 600;
  font-size: 20px;
  line-height: 24px;
}

.v-feed__body {
  font-size: 16px;
  text-align: left;
}
</style>
