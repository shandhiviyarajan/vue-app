<template>
  <div>
    <v-list-item
      v-for="(feedwall, key) in feedwalls"
      :key="key"
      @click="clickHandler(feedwall.id)"
    >
      <v-list-item-title>{{ feedwall.name }}</v-list-item-title>
    </v-list-item>
  </div>
</template>

<script>
export default {
  name: 'FeedWalls',

  methods: {
    clickHandler(event) {
      if (this.$router.currentRoute.name !== 'Home') {
        this.$router.push({ name: 'Home' });
      }
      this.$store.commit('auth/setSelectedFeedWall', parseInt(event));
      this.$store.commit('post/setInitialState');
      this.$store.dispatch('post/getPostList');
    }
  },

  computed: {
    feedwalls() {
      return this.$store.state.auth.commu.feedwalls;
    }
  }
};
</script>
