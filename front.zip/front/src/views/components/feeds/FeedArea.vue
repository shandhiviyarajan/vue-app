<template>
  <div class="feed-wrapper" name="feed wrapper">
    <!-- profile -->

    <div class="d-flex justify-space-between">
      <div class="d-flex">
        <Profile :user="post.user" />
        <Info :createdDate="post.created_at" />
      </div>
      <Reactions
        :likes="post.likes"
        :commentsCount="post.comments.count"
        @toggle-favourite="toggleFavourite"
        :display="true"
      />
    </div>

    <KebabMenu
      v-if="isMenuShow"
      :showMenu="isHovering"
      :items="menuItems"
      @menu-event-dispatch="menuEventHandler"
    />
    <!-- feed -->
    <Feed v-if="!isEditMode" :post="post" />

    <!-- new post -->
    <NewPost
      :view="'post'"
      :data="post"
      :isEditMode="isEditMode"
      v-if="isEditMode"
      v-on:set-edit-mode="setEditModeHandler"
    />
  </div>
</template>

<script>
import Profile from '../profile/Profile';
import Feed from './Feed';
import Info from '../Post/Info';
import Reactions from '../Post/Reactions';
import KebabMenu from '../KekabMenu';
import NewPost from '../Post/NewPost';

export default {
  name: 'FeedArea',

  props: {
    post: Object,
    isHovering: Boolean
  },

  data() {
    return {
      currentUser: this.post.user,
      isEditMode: false
    };
  },

  components: { Profile, Feed, Reactions, KebabMenu, NewPost, Info },

  methods: {
    setEditModeHandler() {
      this.isEditMode = false;
    },
    toggleFavourite(event) {
      if (event.action) {
        this.addFavourite();
      } else {
        this.removeFavourite(event.id);
      }
    },

    addFavourite() {
      this.$store.dispatch('post/addLikeToPost', this.post.id);
    },

    removeFavourite(likeId) {
      this.$store.dispatch('post/deleteLikeFromPost', {
        likeId,
        postId: this.post.id
      });
    },

    menuEventHandler(event) {
      switch (event) {
        case 'edit-post':
          this.isEditMode = true;
          break;
        case 'detele-post':
          this.deletePostById(this.post.id);
          break;
        case 'share-post':
          // eslint-disable-next-line no-console
          console.log('share-post');
      }
    },

    deletePostById(postId) {
      this.$store.dispatch('post/deletePost', postId);
    }
  },

  computed: {
    isMenuShow() {
      if (
        this.user.username === this.currentUser.username &&
        this.user.id === this.currentUser.id
      ) {
        return true;
      }
      return false;
    },

    menuItems() {
      if (this.isMenuShow) {
        return [
          { event: 'edit-post', title: 'Edit Post' },
          { event: 'detele-post', title: 'Delete Post' }
        ];
      }
      return null;
    },

    user() {
      return this.$store.state.auth.user_data;
    }
  }
};
</script>

<style scoped>
.feed-area-container {
}

.profile-menu-conatiner {
  display: flex;
}

.reaction-info-container {
  display: flex;
  align-items: center;
  margin-top: 10px;
}
</style>
