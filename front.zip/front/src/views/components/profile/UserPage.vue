<template>
  <div name="Userpage" id="user_page">
    <v-row class="align-center">
      <v-col cols="12">
        <v-content>
          <v-form @submit.prevent="EditProfile" enctype="multipart/form-data">
            <h1 class="mb-6">Ma Page</h1>
            <div class="v-form-element mb-8">
              <h3>Bienvenue sur le SPOT ! Personnalisez votre profil</h3>
              <h4 class="text--disabled">D'autres personnalisations arriveront très vite.</h4>
            </div>

            <div class="v-form-element">
              <div class="v-section-title">
                Informations générales
                <i class="fa fa-angle-down"></i>
              </div>
            </div>

            <div class="v-form-element">
              <div class="row no-gutters">
                <v-col cols="12" md="12" sm="12">
                  <h4>Photo de profil</h4>
                  <p class="text--disabled">
                    <small>C'est comme cela qu'on vous reconnaîtra le mieux ;)</small>
                  </p>
                </v-col>
                <v-col cols="12" md="12" sm="12">
                  <figure class="v-profile-pic">
                    <div class="v-file__custom">
                      <i class="v-icon-image"></i>
                      <v-file-input filled rounded dense v-model="pp_new"></v-file-input>
                    </div>
                    <img
                      :src="pp ? pp : 'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'"
                    />
                  </figure>
                </v-col>
              </div>
            </div>

            <div class="v-form-element">
              <v-row class="no-gutters">
                <v-col cols="12" md="12" sm="12">
                  <h4>Nom</h4>
                  <p class="text--disabled">
                    <small>Votre nom ou pseudo tel que les autres vous percevront</small>
                  </p>
                </v-col>
                <v-col cols="12" md="12" sm="12">
                  <v-text-field refs="input_file" filled rounded dense v-model="username"></v-text-field>
                </v-col>
              </v-row>
            </div>

            <div class="v-form-element">
              <v-row class="no-gutters">
                <v-col cols="12" md="12" sm="12">
                  <h4>Titre</h4>
                  <p class="text--disabled">
                    <small>I ou deux mots qui vous définissent. . Max 25 lettres</small>
                  </p>
                </v-col>
                <v-col cols="12" md="12" sm="12">
                  <v-text-field
                    filled
                    rounded
                    dense
                    placeholder="Example : Food lover  ❤️"
                    v-model="status"
                  ></v-text-field>
                </v-col>
              </v-row>
            </div>
            <div class="v-form-element mb-6">
              <v-btn
                :loading="(updating)? updating : false"
                class="primary"
                elevation="0"
                type="submit"
              >Update Profile</v-btn>
            </div>
          </v-form>
        </v-content>
      </v-col>
    </v-row>
  </div>
</template>
<script>
import axios from 'axios';
export default {
  name: 'UserPage',
  data() {
    return {
      username: null,
      pp_new: null,
      status: null,
      updating: false,
      preview_img: ''
    };
  },
  computed: {
    user() {
      return this.$store.state.auth.user_data;
    },
    pp: function() {
      return this.$store.state.auth.user_data?.pp;
    }
  },
  methods: {
    EditProfile() {
      this.updating = true;
      let formData = new FormData();
      if (this.pp_new) {
        formData.append('pp', this.pp_new);
      }
      if (this.username) {
        formData.append('username', this.username);
      }
      if (this.status) {
        formData.append('status', this.status);
      }

      return axios
        .patch('auth/users/me/', formData, {
          headers: {
            Authorization: 'JWT ' + this.user.access
          }
        })
        .then(
          response => {
            this.$store.dispatch('auth/pullCommuAndUser');
            this.updating = false;
            this.$router.push({ name: 'UserProfile' });
          },
          error => {
            this.updating = false;
            console.log(error);
          }
        );
    },

    previewImage() {
      var fr = new FileReader();
      console.log(this.$refs.user_image.files[0]);
      console.log(this.pp_new);
      fr.readAsDataURL(this.$refs.user_image.files[0]);
      fr.onload = function(e) {
        this.preview_img = e.target.result;
      };
    }
  }
};
</script>