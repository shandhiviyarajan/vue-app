<template>
  <div id="user-profile">
    <v-row>
      <v-col cols="12">
        <v-content>
          <h1>Profile</h1>
          <div>
            <a href="#" class="text--disabled">
              <i @click="go_back" class="fa fa-angle-left"></i> Return
            </a>
          </div>

          <v-card>
            <div class="v-user-card">
              <div class="d-flex">
                <div class="mr-4 text-center">
                  <v-avatar>
                    <span class="v-user-card__online"></span>
                    <img
                      :src="pp?pp:'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'"
                      alt
                    />
                  </v-avatar>
                  <v-badge class="v-user-card__role">Hero</v-badge>
                </div>
                <div>
                  <div class="d-flex">
                    <div class="v-user-card__name">
                      Shan Dhiviyarajan
                      <div class="v-user-card__host">Developer</div>
                    </div>
                    <div class="v-user-card__joined text--disabled">A rejoint Altesse le 8 June 2020</div>
                  </div>
                  <div class="v-user-card__title">Food Lover 💖</div>
                  <div class="d-flex location-social-links">
                    <div class="v-user-card__location">Sri Lanka - Colombo</div>
                    <div class="v-user-card__social_links">
                      <a href="#" class="text--disabled">
                        <i class="fa fa-twitter"></i>
                      </a>
                      <a href="#" class="text--disabled">
                        <i class="fa fa-globe"></i>
                      </a>
                      <a href="#" class="text--disabled">
                        <i class="fa fa-envelope"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </v-card>

          <v-card class="v-card-for-post">
            <div class="text-center">
              <img src="/assets/svg/post-item.svg" alt />
              <h3 class="text-center mb-6">Vous n’avez pas encore de post</h3>
              <v-btn :ripple="false" depressed class="primary">Créer du contenu</v-btn>
            </div>
          </v-card>
        </v-content>
      </v-col>
    </v-row>
  </div>
</template>


<script>
export default {
  name: 'UserProfile',

  computed: {
    user() {
      return this.$store.state.auth.user_data;
    },
    pp: function() {
      return this.$store.state.auth.user_data?.pp;
    }
  },

  methods: {
    go_back() {
      this.$router.go(-1);
    }
  }
};
</script>