<template>
  <v-menu>
    <template v-slot:activator="{ on }">
      <div class="v-user-card" v-on="on">
        <div class="d-flex">
          <v-avatar size="40">
            <img
              :src="
          user.pp !== null
            ? user.pp
            : default_pp
        "
              :alt="user.username"
            />
          </v-avatar>
          <div class="d-flex align-baseline">
            <div class="v-user-card__name">
              {{ user.username.charAt(0).toUpperCase() + user.username.slice(1) }}
              <div class="v-user-card__host">{{ user.status }}</div>
            </div>
            <v-badge class="v-user-card__role" v-if="user.is_staff">{{ $t("profile.creator") }}</v-badge>
          </div>
        </div>
      </div>
    </template>

    <v-list class="v-avatar--popover">
      <div>
        <div class="d-flex">
          <v-avatar size="40">
            <img
              :src="
          user.pp !== null
            ? user.pp
            : 'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'
        "
              :alt="user.username"
            />
          </v-avatar>
          <div>
            <div class="d-flex align-baseline">
              <div class="v-user-card__name">
                {{ user.username.charAt(0).toUpperCase() + user.username.slice(1) }}
                <div class="v-user-card__host">{{ $t('labels.host') }}</div>
              </div>
              <v-badge class="v-user-card__role" v-if="user.is_staff">{{ $t("profile.creator") }}</v-badge>
            </div>
            <div class="v-avatar__social">
              <small>
                <a href="#">fkatwigs.com • London, UK •</a>
                <a href="#">
                  <i class="fa fa-twitter"></i>
                </a>
                <a href="#">
                  <i class="fa fa-envelope"></i>
                </a>
              </small>
              <p>MAGDALENE is now 💖</p>
              <v-btn :ripple="false" x-small depressed text class="text-primary">
                <img src="/assets/svg/chat_primary.svg" /> Contacter
              </v-btn>
            </div>
          </div>
        </div>
      </div>
    </v-list>
  </v-menu>
</template>

<script>
//import Info from './Info';
export default {
  name: 'Profile',
  props: {
    user: Object
  },
  components: {},
  data() {
    return {
      default_pp: this.$store.state.auth.commu.default_pp
    };
  }
};
</script>

<style scoped>
.profile-container {
  display: flex;
  align-items: center;
  height: 55px;
}
.author-name {
  font-size: 18px;
  font-weight: 700;
}
.author-position {
  font-size: 14px;
  color: #ff7062;
}
</style>
