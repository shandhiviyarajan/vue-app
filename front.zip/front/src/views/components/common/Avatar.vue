
 
  <template>
  <div class="d-flex justify-start align-center py-3">
    <v-avatar color="primary mr-3" size="36">
      <img v-if="getUser.pp" :src="getUser.pp" alt />
      <span
        v-else
        class="white--text headline"
      >{{ getUser.username ? getUser.username.split('')[0].toUpperCase():''}}</span>
    </v-avatar>
    <div class="v-user-name">
      <strong>{{getUser.username}}</strong>
    </div>
  </div>
</template>


<script>
export default {
  name: 'Avatar',
  props: {},
  data: () => ({
    userImage: ''
  }),
  computed: {
    getUser: function() {
      return this.$store.state.auth.user_data;
    }
  }
};
</script>
