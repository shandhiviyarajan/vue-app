<template>
  <div class="v-list-notifications">
    <div class="d-flex v-list-title">
      <h4>Notifications</h4>

      <div>
        <v-btn depressed fab text :ripple="false">
          <i class="icon-mail-opened"></i>
        </v-btn>
        <v-btn depressed fab text :ripple="false">
          <i class="icon-settings"></i>
        </v-btn>
      </div>
    </div>
    <v-list class="v-notify">
      <v-list-item>
        <a href="#/notifications">
          <v-avatar size="36">
            <img src="/assets/images/user.jpg" alt />
          </v-avatar>
          <p>
            <span class="v-notify__user">FKA Twigs</span>
            a aimé votre commentaire sur le post
            <strong>Bâtir le monde no-code post-corona …</strong>
            <small class="v_notify_time">il y’a 8 secondes</small>
          </p>
          <v-btn depressed fab text :ripple="false">
            <i class="icon-x-mark-rounded"></i>
          </v-btn>
        </a>
      </v-list-item>
      <v-list-item>
        <a href="#">
          <v-avatar size="36">
            <img src="/assets/images/user.jpg" alt />
          </v-avatar>
          <p>
            <span class="v-notify__user">FKA Twigs</span>
            a aimé votre commentaire sur le post
            <strong>Bâtir le monde no-code post-corona …</strong>
            <small class="v_notify_time">il y’a 8 secondes</small>
          </p>
          <v-btn depressed fab text :ripple="false">
            <i class="icon-x-mark-rounded"></i>
          </v-btn>
        </a>
      </v-list-item>
      <v-list-item>
        <a href="#">
          <v-avatar size="36">
            <img src="/assets/images/user.jpg" alt />
          </v-avatar>
          <p>
            <span class="v-notify__user">FKA Twigs</span>
            a aimé votre commentaire sur le post
            <strong>Bâtir le monde no-code post-corona …</strong>
            <small class="v_notify_time">il y’a 8 secondes</small>
          </p>
          <v-btn depressed fab text :ripple="false">
            <i class="icon-x-mark-rounded"></i>
          </v-btn>
        </a>
      </v-list-item>
    </v-list>

    <a href="#" x-small>Voir toutes les notifications</a>
  </div>
</template>
<script>
export default {
  name: 'Notifications'
};
</script>