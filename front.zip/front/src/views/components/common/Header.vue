<template>
  <v-app-bar app flat id="app-header" height="80">
    <div class="v-sm v-btn-bars">
      <v-btn fab depressed :ripple="false" @click="toggleSidebar">
        <i class="fa" :class="show_side_bar? 'fa-bars' : 'fa-chevron-left'"></i>
      </v-btn>
    </div>
    <div class="v-sm v-btn-search">
      <v-btn fab depressed :ripple="false" @click="toggleSearch">
        <i class="fa" :class="show_search_bar? 'fa-search' : 'fa-close'"></i>
      </v-btn>
    </div>
    <div class="v-sm v-btn-profile">
      <v-btn fab depressed :ripple="false">
        <img
          :src="pp
                            ? pp
                            : 'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'
                          "
          alt="profile picture"
        />
      </v-btn>
    </div>

    <v-container>
      <v-row no-gutters>
        <v-col cols="12" lg="3" md="3" class="app-header__logo--center">
          <a href="/" class="app-header__logo">
            <img :src="logo ? logo : '/assets/images/logo.png'" />
          </a>
        </v-col>
        <v-col cols="12" lg="6" md="6" id="form-search">
          <div v-if="loggedIn">
            <Search />
          </div>
        </v-col>
        <v-col cols="12" lg="3" md="3" class="app-header__btns--center">
          <div v-if="loggedIn" class="d-flex align-center">
            <div class="position-relative">
              <v-btn
                icon
                rounded
                fab
                depressed
                text
                :ripple="false"
                class="btn-chats"
                v-model="show_chatmessage"
                @click="toggleChatMessage"
              >
                <v-badge v-if="messages" dot overlap right small>
                  <i class="icon-chat"></i>
                </v-badge>
              </v-btn>
              <ChatMessage v-if="show_chatmessage" />
            </div>
            <div class="position-relative">
              <v-btn
                icon
                rounded
                fab
                depressed
                text
                :ripple="false"
                class="btn-notifications"
                v-if="true"
                v-model="show_notifications"
                @click="toggleNotifications"
              >
                <v-badge v-if="notifications" dot overlap right small>
                  <i class="icon-notification"></i>
                </v-badge>
              </v-btn>
              <Notifications v-if="show_notifications" />
            </div>

            <v-menu offset-y class="v-app-profile__dropdown">
              <template v-slot:activator="{ on }">
                <v-btn :ripple="false" v-on="on" depressed fab rounded color="white">
                  <v-avatar size="32" v-on="on">
                    <img
                      :src="pp
                            ? pp
                            : 'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'
                          "
                      :alt="getUser ? getUser.username : ''"
                    />
                  </v-avatar>
                </v-btn>
              </template>

              <v-list>
                <v-list-item class="v-user-info">
                  <Avatar />
                </v-list-item>

                <v-list-item @click="go_to_profile">
                  <v-list-item-title>
                    <router-link to="/profile">Profile</router-link>
                  </v-list-item-title>
                </v-list-item>

                <v-list-item>
                  <v-list-item-title>
                    <router-link to="/account">Settings</router-link>
                  </v-list-item-title>
                </v-list-item>
                <v-divider></v-divider>

                <v-list-item @click="logout">
                  <v-list-item-title>
                    <a href="#">{{$t('buttons.log_out')}}</a>
                  </v-list-item-title>
                </v-list-item>
              </v-list>
            </v-menu>
          </div>
          <div v-else>
            <v-btn
              :ripple="false"
              @click="to_login"
              outlined
              depressed
              class="tertiary"
            >{{$t('buttons.login')}}</v-btn>

            <v-btn
              :ripple="false"
              @click="to_register"
              depressed
              class="primary"
            >{{$t('buttons.register')}}</v-btn>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </v-app-bar>
</template>
    <script>
import Avatar from './Avatar';
import Search from '../search/Search';
import Notifications from './Notifications';
import ChatMessage from './ChatMessage';
export default {
  name: 'Header',
  data() {
    return {
      show_side_bar: true,
      show_search_bar: true,
      show_profile_menu: true,
      notifications: 3,
      messages: 5,
      show_notifications: false,
      show_chatmessage: false
    };
  },
  components: {
    Avatar,
    Search,
    Notifications,
    ChatMessage
  },

  computed: {
    loggedIn: function() {
      return this.$store.state.auth.status.loggedIn;
    },
    logo: function() {
      return this.$store.state.auth.commu.logo;
    },
    pp: function() {
      return this.$store.state.auth.user_data?.pp;
    },
    getUser: function() {
      return this.$store.state.auth.user_data;
    }
  },
  methods: {
    toggleChatMessage() {
      this.show_notifications = false;
      this.show_chatmessage = !this.show_chatmessage;
    },
    toggleNotifications() {
      this.show_chatmessage = false;
      this.show_notifications = !this.show_notifications;
    },
    toggleProfileMenu() {
      this.show_profile_menu = !this.show_profile_menu;
    },
    toggleSearch() {
      this.show_search_bar = !this.show_search_bar;
    },

    toggleSidebar() {
      this.show_side_bar = !this.show_side_bar;
    },
    logout() {
      this.$store.dispatch('auth/logout');
      this.$router.push({ name: 'Login' });
    },
    to_login() {
      this.$router.push({ name: 'Login' });
    },
    to_register() {
      this.$router.push({ name: 'Register' });
    },
    go_to_profile() {
      if (this.$route.name != 'UserProfile')
        this.$router.push({ name: 'UserProfile' });
    },

    messagesClickHandler() {
      //this.$router.push({ name: 'Chat' });
    }
  }
};
</script>