<template>
  <v-content class="v-aside">
    <v-navigation-drawer
      permanent
      clipped
      floating
      width="auto"
      class="v-left-menu"
    >
      <v-list>
        <v-list-item-group color="primary" mandatory>
          <v-list-item-content>Canaux</v-list-item-content>
          <FeedWalls name />
        </v-list-item-group>
        <v-list-item-group color="primary" mandatory>
          <v-list-item-content>Channels</v-list-item-content>
          <Channels name />
        </v-list-item-group>
      </v-list>

      <v-list>
        <v-list-item-group color="primary" v-model="nav_drawer_index" mandatory>
          <v-list-item-content>Général</v-list-item-content>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>📖 Règles de la communauté</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>🙋 À propos</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>📣 Annonces</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>🎙️ Podcasts</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>❓ How to build</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>🚀 Showcase</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>{{ $t('sections.feedwall') }}</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_about">
            <v-list-item-title>{{ $t('sections.about') }}</v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_user_page">
            <v-list-item-title>Ma page</v-list-item-title>
          </v-list-item>
        </v-list-item-group>
      </v-list>
      <v-list>
        <v-list-item-group color="primary" v-model="nav_drawer_index" mandatory>
          <v-list-item-content>Canaux</v-list-item-content>

          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>
              <i class="fa fa-lock" aria-hidden="true"></i> ask
            </v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>
              <i class="fa fa-lock" aria-hidden="true"></i> tutos
            </v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>
              <i class="fa fa-lock" aria-hidden="true"></i> components
            </v-list-item-title>
          </v-list-item>
          <v-list-item @click="go_to_feedwall">
            <v-list-item-title>
              <i class="fa fa-lock" aria-hidden="true"></i> challenges
            </v-list-item-title>
          </v-list-item>
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>
  </v-content>
</template>

<script>
import FeedWalls from '../feeds/FeedWalls';
import Channels from '../chat/Channels';
export default {
  name: 'Aside',

  components: { FeedWalls, Channels },

  data() {
    return {
      nav_drawer_index: '0'
    };
  },

  computed: {
    user() {
      return this.$store.state.auth.user_data;
    },
    loggedIn: function() {
      return this.$store.state.auth.status.loggedIn;
    }
  },

  methods: {
    go_to_feedwall() {
      if (this.nav_drawer_index != 0) {
        this.$router.push({ name: 'Home' });
      }
    },
    go_to_user_page() {
      if (this.nav_drawer_index != 2) {
        this.nav_drawer_index = 2;
        this.$router.push({ name: 'UserPage' });
      }
    },
    go_to_about() {
      if (this.nav_drawer_index != 1) {
        this.$router.push({ name: 'About' });
      }
    }
  }
};
</script>
