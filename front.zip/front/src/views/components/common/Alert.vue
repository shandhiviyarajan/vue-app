<template>
  <v-layout class="alert" justify-center flex-column align-center>
    <div class="alert__img">
      <img src="/assets/svg/success-tick.svg" />
    </div>
    <div class="alert__title">
      <h2>{{ title }}</h2>
    </div>
    <div class="alert__body"></div>
  </v-layout>
</template>

<script>
export default {
  name: 'Alert',
  props: {
    title: String
  }
};
</script>