<template>
  <div class="v-thread__user">
    <div class="d-flex align-center justify-space-between">
      <div class="d-flex">
        <img
          :src="
            user.pp
              ? user.pp
              : 'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'
          "
          alt
        />
        <div>
          <div class="d-flex">
            <p class="v-thread__user-name">{{ chat.author.username }}</p>
            <div class="v-thread__user-role">{{ chat.author.status }}</div>
          </div>
          <div class="v-thread__user-posttime">
            <Time :createdDate="chat.timestamp" />
          </div>
          <div class="v-thread__user-message">{{ chat.body }}</div>
        </div>
      </div>

      <v-menu v-if="isMenuShow" offset-y>
        <template v-slot:activator="{ on }">
          <v-btn :ripple="false" fab text depressed v-on="on" class="v-btn__edit">
            <i class="icon-dots"></i>
          </v-btn>
        </template>
        <v-list>
          <v-list-item v-for="(item, i) in menuItems" :key="i" @click="itemClickHandler">
            <v-list-item-title :id="item.event">
              {{
              item.title
              }}
            </v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </div>
  </div>
</template>

<script>
import Time from '../Post/Info';

export default {
  name: 'Message',

  components: { Time },

  props: {
    chat: Object
  },

  data() {
    return {
      currentUser: this.chat.author
    };
  },

  methods: {
    itemClickHandler(event) {
      this.$emit('menu-event-dispatch', {
        event: event.target.id,
        chat: this.chat
      });
    }
  },

  computed: {
    user: function() {
      return this.$store.state.auth.user_data;
    },

    isMenuShow() {
      if (
        this.user.username === this.currentUser.username &&
        this.user.id === this.currentUser.id
      ) {
        return true;
      }
      return false;
    },

    menuItems() {
      if (this.isMenuShow) {
        return [
          { event: 'edit-message', title: 'Edit message' },
          { event: 'detele-message', title: 'Delete message' }
        ];
      } else {
        return null;
      }
    }
  }
};
</script>
