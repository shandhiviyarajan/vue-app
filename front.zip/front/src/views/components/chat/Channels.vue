<template>
  <div>
    <v-list-item
      v-for="(channel, key) in channels"
      :key="key"
      @click="clickHandler(channel.name, key)"
    >
      <v-icon color="#a09fa9" size="18">mdi-pound</v-icon>
      <v-list-item-title>{{ channel.name }}</v-list-item-title>
    </v-list-item>
  </div>
</template>

<script>
export default {
  name: 'Channels',

  methods: {
    clickHandler(channelName, channelId) {
      if (this.$router.currentRoute.name !== 'Chat') {
        this.$router.push({ name: 'Chat' });
      }
      this.$store.commit('chat/setSelectedChannelName', channelName);
      this.$store.commit('chat/setSelectedChannelId', channelId);
      this.$store.commit('chat/setInitialState');
      this.$store.dispatch('chat/getChatList');
    }
  },

  computed: {
    channels() {
      return this.$store.state.chat.channels;
    }
  }
};
</script>
