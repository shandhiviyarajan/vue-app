<template>
  <v-content id="app-chat">
    <v-row>
      <v-col cols="12">
        <v-card class="v-chat">
          <v-card-title>
            <v-badge class="online" dot inline color="primary"></v-badge>FKA
            Twigs, Curtis Harding
          </v-card-title>
        </v-card>

        <v-card class="v-thread">
          <div
            class="v-all-chats overflow-y-auto"
            v-chat-scroll="{ always: false, smooth: true, enabled: true }"
            v-on:v-chat-scroll-top-reached="loadChat"
          >
            <Message
              :chat="chat"
              v-for="chat in chatList"
              :key="chat.id"
              @menu-event-dispatch="menuEventHandler"
            />
          </div>
        </v-card>

        <v-card class="v-card-chatalter">
          <div class="form-group">
            <v-text-field
              filled
              rounded
              dense
              placeholder="Trouver ou démarrer une conversation"
              name="email"
            />

            <v-btn :ripple="false" depressed class="secondary">Alter</v-btn>
          </div>
          <p>
            <small class="text--mute">Recents</small>
          </p>
          <v-list class="list-chatalter">
            <v-list-item>
              <div class="d-flex align-center">
                <v-avatar size="44">
                  <img src="/assets/images/u1.jpg" alt />
                </v-avatar>
                <div class="list-chatalter__name">FKA Twigs</div>
              </div>

              <div class="list-chatalter__time">il y’a 8 secondes</div>
            </v-list-item>
          </v-list>
        </v-card>

        <v-card class="v-chat-form">
          <v-form>
            <div class="v-form-element">
              <v-textarea
                ref="refMessageTextArea"
                solo
                full-width
                flat
                hide-details
                auto-grow
                placeholder="Message"
                v-model="message"
              ></v-textarea>
              <div class="emoji-container">
                <picker
                  :data="emojiIndex"
                  :perLine="20"
                  :defaultSkin="6"
                  :showPreview="false"
                  :emojiTooltip="true"
                  :sheetSize="32"
                  style="width: 100%; height: 200px;"
                  set="apple"
                  v-show="showEmojiPicker"
                  @select="addEmojiToTextArea"
                />
              </div>
            </div>

            <div class="v-chat-form__btns d-flex">
              <div>
                <v-btn depressed fab :ripple="false">
                  <span class="icon-video-camera"></span>
                </v-btn>
                <v-btn depressed fab :ripple="false">
                  <span class="icon-sheet"></span>
                </v-btn>
                <v-btn depressed fab :ripple="false">
                  <span class="icon-camera"></span>
                </v-btn>
                <v-btn
                  v-tooltip="'Emoji'"
                  @click="emojiActionBtnHandler"
                  depressed
                  fab
                  :ripple="false"
                >
                  <span class="icon-emoji"></span>
                </v-btn>
              </div>
              <v-btn
                v-on:click.prevent="submitBtnClickHandler()"
                depressed
                :ripple="false"
                class="primary"
              >Send</v-btn>
            </div>
          </v-form>
        </v-card>

   
      </v-col>
    </v-row>
  </v-content>
</template>
<script>
import Message from './Message';
import emojiData from '../../../data/all.json';
import { Picker, EmojiIndex } from 'emoji-mart-vue-fast';
import 'emoji-mart-vue-fast/css/emoji-mart.css';

export default {
  name: 'Chat',
  components: { Message, Picker },

  data() {
    return {
      message: '',
      isEditMode: false,
      connection: null,
      textarea_logs: 'No message yet',
      last_message_id: 0,
      default_pp: this.$store.state.auth.commu.default_pp,
      emojiIndex: new EmojiIndex(emojiData),
      showEmojiPicker: false,
      selectedChat: null
    };
  },

  computed: {
    chatList() {
      return this.$store.state.chat.chatList;
    },

    haveNextPage() {
      return this.$store.state.chat.haveNextPage;
    }
  },

  methods: {
    submitBtnClickHandler() {
      if (this.isEditMode) {
        this.editMessage();
        this.isEditMode = false;
      } else {
        this.createMessage();
      }
    },

    addEmojiToTextArea($event) {
      this.message += $event.native;
      this.$refs.refMessageTextArea.focus();
    },

    emojiActionBtnHandler() {
      this.showEmojiPicker = !this.showEmojiPicker;
      this.$refs.refMessageTextArea.focus();
    },

    menuEventHandler(event) {
      this.selectedMessage = event.chat;
      switch (event.event) {
        case 'edit-message':
          this.isEditMode = true;
          this.message = this.selectedMessage.body;
          break;
        case 'detele-message':
          this.deleteMessage(this.selectedMessage);
          break;
      }
    },

    loadChat() {
      if (this.haveNextPage) {
        this.$store.dispatch('chat/getChatList');
      }
    },

    createMessage() {
      this.$socket.sendObj({
        type: 'create_message',
        body: this.message,
        channel_id: this.$store.state.chat.selectedChannelId
      });
      this.message = '';
    },

    editMessage() {
      this.$socket.sendObj({
        type: 'edit_message',
        body: this.message,
        channel_id: this.selectedMessage.channel.id,
        message_id: this.selectedMessage.id
      });
      this.message = '';
    },

    deleteMessage(chat) {
      this.$socket.sendObj({
        type: 'delete_message',
        channel_id: chat.channel.id,
        message_id: chat.id
      });
      this.message = '';
    }
  }
};
</script>
