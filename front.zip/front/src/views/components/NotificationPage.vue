<template>
  <v-content class="notification-page">
    <v-switch
      :ripple="false"
      v-model="is_notification"
      :label="is_notification ? 'Switch on' : 'Off'"
    ></v-switch>

    <div v-if="is_notification">
      <h3>Notification Page</h3>
      <p>Gérer les notifications de votre compte pour les nouveaux commentaires, mentions, réactions, et posts</p>

      <table>
        <tr>
          <th>Être notifié lors de</th>

          <th>E-mail</th>

          <th>In-app</th>
        </tr>

        <tr>
          <td>Commentaires sur mes posts</td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
        </tr>

        <tr>
          <td>Réponses à mes commentaires</td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
        </tr>

        <tr>
          <td>Mentions me concernant</td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
        </tr>

        <tr>
          <td>Likes sur mes posts</td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
        </tr>

        <tr>
          <td>Likes sur mes commentaires</td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
          <td>
            <v-checkbox></v-checkbox>
          </td>
        </tr>
      </table>

      <v-btn large depressed text :ripple="false" class="primary">Enregistrer les modifications</v-btn>
    </div>

    <div v-else>
      <v-card class="d-flex justify-space-between align-center mb-6">
        <h3>Notification Page</h3>
        <i class="icon-settings"></i>
      </v-card>

      <v-card>
        <p class="text-center mb-0">Vous n’avez pas de nouvelle notification</p>
      </v-card>
    </div>

    <div>
      <v-card class="mt-6">
        <v-list class="notification-list">
          <v-list-item>
            <v-avatar size="44">
              <img src="/assets/images/u1.jpg" alt />
            </v-avatar>
            <p>
              <span class="notification-list__user">FKA Twigs</span>
              a aimé votre commentaire sur le post Bâtir le monde no-code post-corona ...
              <small>il y’a 8 secondes</small>
            </p>
          </v-list-item>
        </v-list>
      </v-card>
    </div>
  </v-content>
</template>

<script>
export default {
  name: 'NotificationPage',

  data() {
    return {
      is_notification: true,
      notification_list: [
        {
          pp: 'u1.jpg',
          name: '',
          time: 'il y’a 8 secondes',
          message:
            'a aimé votre commentaire sur le post Bâtir le monde no-code post-corona a aimé votre commentaire sur le post Bâtir le monde no-code post-corona'
        }
      ]
    };
  },
  mounted() {},

  methods: {}
};
</script>