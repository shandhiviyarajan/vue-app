<template>
  <v-content>
    <v-card class="v-members">
      <v-card-title>Membres actifs</v-card-title>
      <v-list>
        <v-list-item v-for="v_member in v_members" :key="v_member">
          <Member />
        </v-list-item>

        <v-list-item>
          <v-btn x-small :ripple="false" fab text depressed>Tout voir</v-btn>
        </v-list-item>
      </v-list>
    </v-card>
  </v-content>
</template>

<script>
import Member from './Member';
export default {
  name: 'Members',
  components: {
    Member
  },
  data() {
    return {
      v_members: 5
    };
  }
};
</script>