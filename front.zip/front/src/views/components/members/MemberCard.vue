<template>
  <v-card class="v-member-card">
    <a href="#" class="v-member-card__chat">
      <i class="icon-chat"></i>
    </a>
    <div class="text-center">
      <v-avatar size="96">
        <span class="v-member-card__online"></span>
        <img
          :src="pp?pp:'https://geeko.lesoir.be/wp-content/uploads/sites/58/2019/01/boo-chien-plus-mignon-du-monde-mort-1068x712.jpg'"
          alt
        />
      </v-avatar>
      <v-badge class="v-member-card__role">Admin</v-badge>
    </div>
    <div class="v-member-card__name">Shan Dhiviyarajan</div>
    <div class="v-member-card__title">Food Lover 💖</div>
    <div class="v-member-card__tags">
      <span>Staff</span>
      <span>Pro Member</span>
    </div>

    <div class="v-member-card__location">Sri Lanka - Colombo</div>
    <div class="v-member-card__social_links">
      <a href="#">
        <i class="fa fa-twitter"></i>
      </a>
    </div>
  </v-card>
</template>

<script>
export default {
  name: 'MemberCard',
  data() {
    return {};
  },

  computed: {
    user() {
      return this.$store.state.auth.user_data;
    },
    pp: function() {
      return this.$store.state.auth.user_data?.pp;
    }
  }
};
</script>