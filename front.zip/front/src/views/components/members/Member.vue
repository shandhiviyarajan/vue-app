<template>
  <div class="v-member">
    <a href="#">
      <img src="/assets/images/u-1.jpg" alt />
      <div class="v-member__name">Shan Dhiviyarajan</div>
    </a>
  </div>
</template>

<script>
export default {
  name: 'Member'
};
</script>