<template>
  <v-row>
    <v-col cols="12" sm="6" md="4" lg="4" v-for="member in members" :key="member">
      <MemberCard />
    </v-col>
  </v-row>
</template>

<script>
import MemberCard from './MemberCard';
export default {
  name: 'MembersGrid',
  components: {
    MemberCard
  },
  data() {
    return {
      members: 5
    };
  }
};
</script>