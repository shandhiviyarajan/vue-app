<template>
  <div class="scroll-loader">
    <div class="loader" v-show="!loaderDisable">
      <slot>
        <svg viewBox="25 25 50 50" class="svg" :style="size">
          <circle cx="50" cy="50" r="20" class="circle" :style="color" />
        </svg>
      </slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ScrollLoader',

  props: {
    loaderMethod: {
      type: Function,
      required: true
    },
    loaderDisable: {
      type: Boolean,
      default: false
    },
    loaderDistance: {
      type: Number,
      default: 0
    },
    loaderColor: {
      type: String,
      default: '#CCCCCC'
    },
    loaderSize: {
      type: Number,
      default: 50
    },
    loaderViewport: {
      type: Element,
      default: null
    }
  },

  computed: {
    size() {
      return {
        width: `${this.loaderSize}px`
      };
    },
    color() {
      return {
        stroke: this.loaderColor
      };
    },
    options() {
      return {
        root: this.loaderViewport,
        rootMargin: `0px 0px ${this.loaderDistance}px 0px`
      };
    },
    observer() {
      return new IntersectionObserver(([{ isIntersecting }]) => {
        isIntersecting && !this.loaderDisable && this.loaderMethod();
      }, this.options);
    }
  },

  mounted() {
    this.observer.observe(this.$el);
  },

  activated() {
    this.observer.observe(this.$el);
  },

  deactivated() {
    this.observer.unobserve(this.$el);
  },

  beforeDestroy() {
    this.observer.unobserve(this.$el);
  }
};
</script>
