<template>
  <div class="feed-item-link">
    <a target="_blank" :href="link.link_preview_url" class="link-container">
      <div class="link-image">
        <img :src="link.link_preview_image_url" />
      </div>
      <div class="link-info">
        <div class="title-container">
          <img src="/assets/images/small.png" width="16" height="16" />
          <div class="link-title">{{ link.link_preview_title }}</div>
        </div>
        <div class="link-description">
          {{ link.link_preview_description }}
        </div>
      </div>
    </a>
  </div>
</template>

<script>
export default {
  name: 'Link',

  props: {
    link: Object
  }
};
</script>
