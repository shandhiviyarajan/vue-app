<template>
  <v-row align="center" justify="center">
    <v-col cols="12" md="12">
      <!-- main header -->
      <div class="top-header">
        <h1 class="altesse-header">{{ commu_name }}</h1>
        <div class="altesse-description">{{ commu_bio }}</div>
      </div>
      <div>
        <NewPost :feedwall="feedwall" :view="'post'" v-on:updatePostList="updatePostList" />
      </div>
     
    </v-col>
  </v-row>
</template>

<script>
import NewPost from './NewPost';

export default {
  name: 'CreateNewPost',

  props: {
    feedwall: Number
  },
  computed: {
    commu_bio() {
      return this.$store.state.auth.commu.bio;
    },
    commu_name() {
      return this.$store.state.auth.commu.name;
    }
  },

  components: { NewPost },

  methods: {
    updatePostList() {
      // eslint-disable-next-line no-console
      console.log('CreateNewPost updatePostList');
      this.$emit('updatePostList');
    }
  }
};
</script>

<style scoped>
[v-cloak] {
  display: none;
}

.top-header {
}

.altesse-header {
  font-size: 2.5rem;
  font-weight: 700;
  line-height: 2rem;
  letter-spacing: 0.0573529412em;
}

.altesse-description {
  font-size: 1rem;
  font-weight: 400;
  margin-bottom: 20px;
}

.post-avatar {
  margin-left: 10px;
  margin-right: 10px;
  margin-top: 5px;
}
</style>
