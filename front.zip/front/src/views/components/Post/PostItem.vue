<template>
  <v-card class="post-item">
    <div
      v-on:mouseover.prevent="mouseover"
      v-on:mouseleave.prevent="mouseleave"
      :class="{ 'container-over': isHovering }"
    >
      <FeedArea :isHovering="isHovering" @load-post="loadPost" :post="post" />
      <CommentArea :postId="post.id" :comments="post.comments" />
    </div>
  </v-card>
</template>

<script>
import FeedArea from '../feeds/FeedArea';
import CommentArea from '../comments/CommentArea';

export default {
  name: 'PostItem',

  components: { FeedArea, CommentArea },

  props: {
    post: Object
  },

  data() {
    return {
      isHovering: false
    };
  },

  methods: {
    mouseover: function() {
      this.isHovering = true;
    },

    mouseleave: function() {
      this.isHovering = false;
    },

    loadPost() {
      this.$emit('load-post');
    }
  }
};
</script>
