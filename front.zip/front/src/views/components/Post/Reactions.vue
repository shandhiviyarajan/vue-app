<template>
  <div class="v-reactions">
    <div class="v-reactions__buttons">
      <v-btn rounded fab :ripple="false" text>
        <i class="icon-react"></i>
      </v-btn>
      <v-btn rounded :ripple="false" fab text>
        <i class="icon-comment"></i>
        <span v-if="display" class="v-comments-count">{{ commentsCount }}</span>
      </v-btn>

      <v-btn
        class="v-heart-icon"
        rounded
        :ripple="false"
        fab
        text
        @click="favouriteToggleHandler()"
      >
        <i :class="liked ? 'icon-heart fill' : 'icon-heart'"></i>

        <span
          :class="likes.user_liked ? 'v-likes-count' : 'v-comments-count'"
        >{{ likes.likes_count }}</span>
      </v-btn>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Reactions',

  props: {
    display: Boolean,
    commentsCount: Number,
    likes: Object
  },

  data() {
    return {
      liked: false,
      heartAnim: false,
      t: 1
    };
  },

  methods: {
    favouriteToggleHandler() {
      this.liked = !this.likes.user_liked;

      this.$emit('toggle-favourite', {
        action: !this.likes.user_liked,
        id: this.likes.user_like_id
      });
    },

    playAnim() {
      if (this.t === 1) {
        this.t = -1;
      } else {
        this.t = 1;
      }

      this.heartAnim.setDirection(this.t);
      this.heartAnim.play();
    }
  },
  mounted() {
    // this.heartAnim = this.$refs.lt;
    // this.heartAnim.load('/assets/json/heart.json');

    if (this.likes.user_liked) {
      this.liked = true;
    }
  }
};
</script>
