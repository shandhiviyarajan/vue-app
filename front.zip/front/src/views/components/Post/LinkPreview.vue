<template>
  <div v-if="show" class="link-preview">
    <div
      id="loader-container"
      v-if="!response && validUrl"
      :style="{ width: '400px' }"
    >
      <slot name="loading">
        <div class="spinner"></div>
      </slot>
    </div>
    <div v-if="response" class="preview">
      <div class="link-preview-img-holder">
        <div ref="refImgHolder" class="link-preview-img"></div>
      </div>
      <div class="link-preview-info-holder">
        <div class="link-preview-title">{{ response.title }}</div>
        <div class="link-preview-description">{{ response.description }}</div>
      </div>
      <div>
        <button @click="closePreview" class="remove-item-btn"></button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LinkPreview',

  props: {
    url: String
  },

  data() {
    return {
      response: null,
      validUrl: false,
      apiUrl: 'https://linkpreview-api.herokuapp.com/',
      show: false
    };
  },

  methods: {
    closePreview() {
      this.show = false;
      this.$emit('link-preview-close');
    },

    isValidUrl: function(url) {
      const regex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)/;
      this.validUrl = regex.test(url);
      return this.validUrl;
    },

    setDivImageBackground() {
      this.$nextTick(function() {
        this.$refs.refImgHolder.style.backgroundImage = `url(${this.response.images[0]})`;
      });
    },

    getLinkPreview: function() {
      if (this.isValidUrl(this.url)) {
        this.httpRequest(
          response => {
            this.response = JSON.parse(response);
            this.setDivImageBackground();
          },
          () => {
            this.response = null;
            this.validUrl = false;
          }
        );
      }
    },

    httpRequest: function(success, error) {
      this.show = true;
      const http = new XMLHttpRequest();
      const params = 'url=' + this.url;
      http.open('POST', this.apiUrl, true);
      http.setRequestHeader(
        'Content-type',
        'application/x-www-form-urlencoded'
      );
      http.onreadystatechange = function() {
        if (http.readyState === 4 && http.status === 200) {
          success(http.responseText);
        }
        if (http.readyState === 4 && http.status === 500) {
          error();
        }
      };
      http.send(params);
    }
  },

  watch: {
    // eslint-disable-next-line no-unused-vars
    url: function(value) {
      this.response = null;
      this.getLinkPreview();
    },

    response: function(value) {
      this.$emit('link-response', value);
    }
  },

  created() {
    this.getLinkPreview();
  }
};
</script>

<style scoped>
.remove-item-btn {
  background-image: url('/assets/images/icon.png');
  background-size: cover;
  width: 20px;
  height: 20px;
  position: absolute;
  top: -10px;
  right: -10px;
}

.link-preview-title {
  white-space: nowrap;
  width: 92%;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 14px;
  font-weight: 600;
  color: #0d0b23;
}

.link-preview-description {
  margin-top: 10px;
  text-align: justify;
  overflow: hidden;
  text-overflow: ellipsis;
  max-height: 110px;
  color: #f9625a;
  font-size: 12px;
}

.link-preview {
  background-color: #f3f3f4;
  border-radius: 8px;
  margin-top: 10px;
}

.preview {
  display: flex;
}

.link-preview-info-holder {
  margin: 10px;
  width: 80%;
}

.link-preview-img-holder {
  width: 64px;
  height: 64px;
  position: relative;
  margin: 10px;
}

.link-preview-img {
  height: 100%;
  position: relative;
  background-size: cover;
  background-position: center;
  border-radius: 4px;
}

.spinner {
  margin-left: 90%;
  height: 28px;
  width: 28px;
  animation: rotate 0.8s infinite linear;
  border: 5px solid #868686;
  border-right-color: transparent;
  border-radius: 50%;
}

@keyframes rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>
