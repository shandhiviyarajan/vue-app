<template>
  <div class="feed-info ml-3">
    <!--{{ $t('labels.posted_on') }}-->
    <TimeAgo :datetime="createdDate" :refresh="60" locale="fr" :long="true" />
  </div>
</template>

<script>
import TimeAgo from 'vue2-timeago';

export default {
  name: 'Info',

  components: { TimeAgo },

  props: {
    createdDate: String
  }
};
</script>

<style scoped>
.feed-info {
  display: inline-block;
  font-size: 13px;
  color: #abb0b9;
}

.feed-info >>> .v-time-ago__text {
  color: #abb0b9;
  font-family: 'Nunito', sans-serif;
  font-size: 13px;
}
</style>
