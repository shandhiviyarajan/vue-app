<template>
  <v-card class="v-new-post mb-6">
    <div v-if="view === 'post' && !isEditMode" class="header">
      <div class="d-flex mb-3">
        <span class="v-icon-feather-rounded"></span>
        <div>{{ $t('labels.header') }}</div>
      </div>

      <div
        ref="refUndoPostCreation"
        @click="postCloseBtnHandler"
        v-if="closeBtnDisplayed"
        class="icon"
      ></div>
    </div>
    <div ref="refWrapper">
      <div :class="view === 'post' ? 'editor' : 'editor-comment'">
        <div ref="refEditorContainer" tabindex="0" class="editor-container">
          <v-form ref="refForm" enctype="multipart/form-data">
            <drop class="drop" @drop="dragAndDropHandler">
              <!-- editor -->
              <div class="editable-area-container">
                <!-- eslint-disable-next-line vue/valid-v-model -->
                <div
                  v-if="isEditMode"
                  style="margin-top: 7px; margin-left: 10px; margin-right: 10px;"
                  ref="editableRef"
                  contenteditable="true"
                  v-on:focus="textAreaFocusHandler"
                  v-on:blur="textAreaFocusOutHandler($event)"
                ></div>
                <textarea
                  v-if="!isEditMode"
                  :placeholder="
                    view === 'post'
                      ? this.$t('labels.share_whats_on_your_mind')
                      : this.$t('labels.comment')
                  "
                  ref="refPostTextArea"
                  v-on:focus="textAreaFocusHandler"
                  v-on:blur="textAreaFocusOutHandler($event)"
                  @input="autoExpandTextArea"
                  class="post-text-area"
                  v-model="postContent"
                ></textarea>
              </div>
              <!-- emoji -->
              <div class="emoji-container">
                <picker
                  :data="emojiIndex"
                  :perLine="20"
                  :defaultSkin="6"
                  :showPreview="false"
                  :emojiTooltip="true"
                  :sheetSize="32"
                  style="width: 100%; height: 200px;"
                  set="apple"
                  v-show="showEmojiPicker"
                  @select="addEmojiToTextArea"
                />
              </div>
              <!-- action buttons -->
              <div class="action-btn-container">
                <div>
                  <button
                    @click="emojiActionBtnHandler"
                    v-tooltip="'Emoji'"
                    class="emoji-btn"
                  ></button>
                </div>
                <!-- emoji -->
                <div class="emoji-container">
                  <picker
                    :data="emojiIndex"
                    :perLine="20"
                    :defaultSkin="6"
                    :showPreview="false"
                    :emojiTooltip="true"
                    :sheetSize="32"
                    style="width: 100%; height: 200px;"
                    set="apple"
                    v-show="showEmojiPicker"
                    @select="addEmojiToTextArea"
                  />
                </div>
                <!-- action buttons -->
                <div class="action-btn-container">
                  <div>
                    <button
                      @click="emojiActionBtnHandler"
                      v-tooltip="'Emoji'"
                      class="emoji-btn"
                    ></button>
                  </div>
                </div>
                <!-- end of action buttons  -->
              </div>
            </drop>
          </v-form>
        </div>
        <div>
          <!-- image preview -->
          <div
            v-if="isImageSelected && showPreview"
            class="image-video-container"
          >
            <img
              :src="srcImagePreview"
              class="image-preview"
              v-show="showPreview"
            />
            <button
              @click="removeSelectedImage"
              class="remove-item-btn"
            ></button>
          </div>

          <!-- video preview -->
          <div
            v-if="isVideoSelected && showPreview"
            class="image-video-container"
          >
            <video style="border-radius: 4px;" width="400" controls>
              <source :src="srcSelectedVideo" type="video/mp4" />
            </video>
            <button
              @click="removeSelectedImage"
              class="remove-item-btn"
            ></button>
          </div>

          <!-- file preview -->
          <div
            v-if="isOtherSelected && showPreview"
            class="other-file-container"
          >
            <div
              style=" border-radius: 8px; background-color: #F3F3F4;display: flex; align-items: center; padding: 10px;"
            >
              <i
                style="font-size: 48px; color: #f9625a;"
                class="fa fa-file"
              ></i>
              <div
                style="margin-left: 10px; margin-right: 10px; color: #0d0c22; font-size: 14px; font-weight: 600;"
              >
                {{ otherFileName }}
              </div>
              <button
                @click="removeSelectedImage"
                class="remove-item-btn"
              ></button>
            </div>
          </div>

          <!-- link -->
          <div class="link-container" v-if="isLinkSelected">
            <div v-if="isLinkInputShow" style="position: relative;">
              <input
                ref="refLinkInput"
                autocomplete="off"
                @paste.prevent="linkPasteHandler($event)"
                class="paste-link-input"
                v-model="pastedLink"
                :placeholder="this.$t('labels.paste-link-here')"
                type="text"
              />
              <button @click="linkInputRemove" class="remove-item-btn"></button>
            </div>
            <!-- file preview -->
            <div
              v-if="isOtherSelected && showPreview"
              class="other-file-container"
            >
              <div style="display: flex; align-items: center; padding: 10px;">
                <i style="font-size: 36px;" class="fa fa-file">
                  <span
                    style="margin-left: 10px; margin-right: 10px; font-size: 18px;"
                    >{{ otherFileName }}</span
                  >
                </i>
                <span>
                  <v-icon @click="removeSelectedOtherFile"
                    >mdi-close-box</v-icon
                  >
                </span>
              </div>
            </div>
            <!-- error -->
            <div v-if="isErrorOccured" class="error-container">
              {{ uploadedErrorMassage }}
              <span style="margin-left: 10px;">
                <v-icon @click="removeError" color="#e04247"
                  >mdi-close-circle-outline</v-icon
                >
              </span>
            </div>
            <!-- link preview -->
            <div class="link-container" v-if="isLinkSelected">
              <div v-if="isLinkInputShow"></div>
              <div class="link-preview">
                <LInkPreview
                  @link-preview-close="linkPreviewCloseHandler"
                  v-if="pastedLink"
                  :url="pastedLink"
                  @link-response="linkResponseRecieved"
                />
              </div>
            </div>
          </div>

          <!-- error -->
          <div v-if="isErrorOccured" class="error-container">
            {{ uploadedErrorMassage }}
            <span style="margin-left: 10px;">
              <v-icon @click="removeError" color="#e04247"
                >mdi-close-circle-outline</v-icon
              >
            </span>
          </div>
        </div>
      </div>

      <div
        :class="
          view === 'post'
            ? 'action-button-container'
            : 'action-button-container-comment'
        "
      >
        <input
          v-if="view === 'post'"
          @change="fileUploadSelectHandler"
          ref="refFileUploader"
          type="file"
          style="display: none;"
        />
        <div class="d-flex justify-space-between">
          <div>
            <v-btn
              v-if="view === 'post'"
              v-tooltip="
                isLinkSelected
                  ? 'You can not add media while link is selected'
                  : 'Upload image / video / file'
              "
              @click="fileUploadActionBtnHandler"
              small
              icon
              color="#abb0b9"
            >
              <v-icon dark>mdi-camera</v-icon>
            </v-btn>
            <v-btn
              v-if="view === 'post'"
              v-tooltip="
                isImageSelected || isVideoSelected
                  ? 'You can not add link while media is selected'
                  : 'Add article link'
              "
              @click="linkActionBtnHandler"
              small
              icon
              color="#abb0b9"
            >
              <v-icon dark>mdi-link-variant</v-icon>
            </v-btn>
          </div>

          <button
            ref="refSubmitBtn"
            disabled
            v-on:click.prevent="submitBtnClickHandler()"
            class="post-btn"
          >
            {{ submitBtnText }}
            <i
              v-if="isSending"
              style="color: #fff;"
              class="fa fa-circle-o-notch fa-spin"
            ></i>
          </button>
          <button
            v-if="isEditMode"
            v-on:click.prevent="cancelEdit()"
            class="cancel-btn"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  </v-card>
</template>

<script>
import emojiData from '../../../data/all.json';
import { Picker, EmojiIndex } from 'emoji-mart-vue-fast';
import LInkPreview from './LinkPreview';
import 'emoji-mart-vue-fast/css/emoji-mart.css';
import { Drop } from 'vue-drag-drop';

const MAX_SIZE = 50;

export default {
  name: 'NewPost',

  components: { Picker, LInkPreview, Drop },

  props: {
    view: String,
    isEditMode: Boolean,
    data: Object,
    postId: Number
  },

  data() {
    return {
      isImageSelected: false,
      isVideoSelected: false,
      selectedFile: null,
      uploadedErrorMassage: '',
      isErrorOccured: false,
      showPreview: false,
      srcImagePreview: '',
      srcSelectedVideo: '',
      pastedLink: '',
      isLinkSelected: false,
      isLinkInputShow: false,
      linkResponse: '',
      showEmojiPicker: false,
      postContent: '',
      submitBtnText: '',
      isSending: false,
      emojiIndex: new EmojiIndex(emojiData),
      isOtherSelected: false,
      otherFileName: '',
      isFileChanged: false,
      isLinkResponseChanged: false,
      isImageChanged: false,
      isVideoChanged: false,
      closeBtnDisplayed: false,
      btnDisplayed: true
    };
  },

  methods: {
    /** text area */
    autoExpandTextArea() {
      let textArea = this.$refs.refPostTextArea;
      let outerHeight = parseInt(window.getComputedStyle(textArea).height, 10);
      let clientHeight = textArea.clientHeight;
      let diff = outerHeight - clientHeight;
      let minHeight = textArea.scrollHeight;
      textArea.style.height = 0;
      textArea.style.height = `${Math.max(
        minHeight,
        textArea.scrollHeight + diff
      )}px`;
    },

    postCloseBtnHandler() {
      this.postContent = '';
      this.setContainerToInitialHeight();
      this.closeBtnDisplayed = false;
    },

    textAreaFocusOutHandler($event) {
      if (
        this.postContent !== '' ||
        this.isImageSelected ||
        this.isVideoSelected ||
        this.isLinkSelected
      ) {
        return;
      } else {
        if (!this.$refs.refWrapper.contains($event.relatedTarget)) {
          this.setContainerToInitialHeight();
        }
      }
    },

    textAreaFocusHandler() {
      this.$refs.refEditorContainer.style.maxHeight = `4000px`;
      this.$refs.refEditorContainer.style.borderRadius = `8px`;
      this.$refs.refEditorContainer.style.borderStyle = `solid`;
      this.$refs.refEditorContainer.style.borderColor = `#ffcec1`;
      this.$refs.refEditorContainer.style.borderWidth = `1px`;
      this.$refs.refEditorContainer.style.backgroundColor = `#fff`;
    },

    setFocustTotextArea() {
      this.$refs.refPostTextArea.focus();
    },

    setContainerToInitialHeight() {
      this.$refs.refPostTextArea.style.height = `60px`;
      this.$refs.refEditorContainer.style.maxHeight = `40px`;
      this.$refs.refEditorContainer.style.border = `none`;
      this.$refs.refEditorContainer.style.backgroundColor = `#F3F3F4`;
    },

    /** action buttons */

    fileUploadActionBtnHandler() {
      if (this.isLinkSelected) return;
      this.isLinkSelected = false;

      this.$refs.refFileUploader.click();
      if (this.postContent === '') {
        this.setContainerToInitialHeight();
      }
    },

    linkActionBtnHandler() {
      if (this.isImageSelected || this.isVideoSelected) return;
      if (this.isErrorOccured) this.removeError();
      this.isLinkSelected = true;
      this.isLinkInputShow = true;
      if (this.postContent === '') {
        this.setContainerToInitialHeight();
      }

      this.$nextTick(function() {
        this.$refs.refLinkInput.focus();
      });
    },

    emojiActionBtnHandler(event) {
      event.preventDefault();
      this.showEmojiPicker = !this.showEmojiPicker;
      if (this.isEditMode) {
        this.$refs.editableRef.focus();
      } else {
        this.$refs.refPostTextArea.focus();
      }
    },

    /** image & video file upload */
    fileUploadSelectHandler() {
      this.selectedFile = this.$refs.refFileUploader.files[0];
      if (this.isFileSizeAllowed(this.selectedFile.size)) {
        this.seletMedia(this.selectedFile.type);
      } else {
        this.isErrorOccured = true;
        this.uploadedErrorMassage = 'Selected file exceed the file size';
      }
    },

    dragAndDropHandler(data, event) {
      event.preventDefault();
      this.setFocustTotextArea();
      this.selectedFile = event.dataTransfer.files[0];
      if (this.isFileSizeAllowed(this.selectedFile.size)) {
        this.seletMedia(this.selectedFile.type);
      } else {
        this.isErrorOccured = true;
        this.uploadedErrorMassage = 'Selected file exceed the file size';
      }
    },

    imageHandler() {
      this.isImageSelected = true;
      this.uploadedErrorMassage = '';
      this.isErrorOccured = false;
      this.isVideoSelected = false;

      let imageReader = new FileReader();
      imageReader.addEventListener(
        'load',
        function() {
          this.showPreview = true;
          this.srcImagePreview = imageReader.result;
        }.bind(this),
        false
      );

      if (this.selectedFile) {
        imageReader.readAsDataURL(this.selectedFile);
      }
      this.isImageChanged = true;
    },

    videoHandler() {
      this.showPreview = true;
      this.isVideoSelected = true;
      this.isImageSelected = false;
      this.uploadedErrorMassage = '';
      this.isErrorOccured = false;
      this.srcSelectedVideo = URL.createObjectURL(this.selectedFile);
      this.isVideoChanged = true;
    },

    otherFileHandler() {
      this.isFileChanged = true;
      this.showPreview = true;
      this.isOtherSelected = true;
      this.otherFileName = this.selectedFile.name;
    },

    seletMedia() {
      if (this.selectedFile.type.includes('video/')) {
        this.videoHandler();
      } else if (this.selectedFile.type.includes('image/')) {
        this.imageHandler();
      } else if (this.selectedFile.type.includes('application/')) {
        this.otherFileHandler();
      }
    },

    isFileSizeAllowed(size) {
      let videoSize = Math.round(size / 1024 / 1024);
      return MAX_SIZE > videoSize;
    },

    removeSelectedImage() {
      this.showPreview = false;
      this.isImageSelected = false;
      this.srcImagePreview = '';
      this.selectedFile = null;
      this.isImageChanged = true;
      //this.setFocustTotextArea();
    },

    removeSelectedVideo() {
      this.showPreview = false;
      this.isVideoSelected = false;
      this.srcSelectedVideo = '';
      this.selectedFile = null;
      this.isVideoChanged = true;
      //this.setFocustTotextArea();
    },

    removeSelectedOtherFile() {
      this.showPreview = false;
      this.isOtherSelected = false;
      this.selectedFile = null;
      this.isFileChanged = true;
      //this.setFocustTotextArea();
    },

    removeError() {
      this.uploadedErrorMassage = '';
      this.isErrorOccured = false;
      //this.setFocustTotextArea();
    },

    /** link paste */

    linkPasteHandler($event) {
      let clipboardData =
        $event.clipboardData ||
        $event.originalEvent.clipboardData ||
        window.clipboardData;
      let replacedData = clipboardData.getData('text');
      this.pastedLink = replacedData;
      this.isLinkResponseChanged = true;
    },

    linkPreviewCloseHandler() {
      this.pastedLink = '';
      this.linkResponse = '';
      this.isLinkSelected = false;
      this.isLinkResponseChanged = true;
      //this.setFocustTotextArea();
    },

    linkResponseRecieved($event) {
      this.isLinkInputShow = false;
      this.linkResponse = $event;
      //this.setFocustTotextArea();
    },

    linkInputRemove() {
      this.isLinkInputShow = false;
      this.linkResponse = null;
      this.isLinkSelected = false;
      //this.setFocustTotextArea();
    },

    /** emoji */

    addEmojiToTextArea($event) {
      if (this.isEditMode) {
        this.postContent += $event.native;
        this.$refs.refPostTextArea.focus();
      } else {
        this.$refs.editableRef.innerHTML += $event.native;
        this.postContent = this.$refs.editableRef.innerHTML;
        this.$refs.editableRef.focus();
      }
    },

    submitBtnClickHandler() {
      this.isSending = true;
      this.submitBtnText = 'Sending...';
      if (this.isEditMode) {
        if (this.view === 'post') {
          this.updatePost();
        } else {
          this.updateComment();
        }
      } else {
        if (this.view === 'post') {
          this.createNewPost();
        } else {
          this.createNewComment();
        }
      }
    },

    cancelEdit() {
      this.$emit('set-edit-mode');
    },

    updatePost() {
      let formData = new FormData();
      this.postContent = this.$refs.editableRef.innerHTML;
      if (this.postContent && this.postContent !== this.data.body) {
        formData.append('body', this.postContent);
      }

      if (this.selectedFile && this.isOtherSelected) {
        if (this.isFileChanged) formData.append('file', this.selectedFile);
      } else {
        if (this.isFileChanged) formData.append('file', '');
      }

      if (this.linkResponse && this.isLinkSelected) {
        if (this.isLinkResponseChanged) {
          formData.append('link_preview_url', this.linkResponse.url);
          formData.append('link_preview_title', this.linkResponse.title);
          formData.append(
            'link_preview_description',
            this.linkResponse.description
          );
          formData.append(
            'link_preview_image_url',
            this.linkResponse.images[0]
          );
        }
      } else {
        if (this.isLinkResponseChanged) {
          formData.append('link_preview_url', '');
          formData.append('link_preview_title', '');
          formData.append('link_preview_description', '');
          formData.append('link_preview_image_url', '');
        }
      }

      if (this.selectedFile && this.isImageSelected) {
        if (this.isImageChanged) formData.append('image', this.selectedFile);
      } else {
        if (this.isImageChanged) formData.append('image', '');
      }

      if (this.selectedFile && this.isVideoSelected) {
        if (this.isVideoChanged) formData.append('video', this.selectedFile);
      } else {
        if (this.isVideoChanged) formData.append('video', '');
      }

      this.$store
        .dispatch('post/updatePost', {
          postId: this.data.id,
          updatedPost: formData
        })
        .then(() => {
          this.$emit('set-edit-mode');
          this.resetPost();
        });
    },

    updateComment() {
      let formData = new FormData();
      this.postContent = this.$refs.editableRef.innerHTML;
      if (this.postContent) {
        formData.append('body', this.postContent);
      }

      this.$store
        .dispatch('post/updateComment', {
          commentId: this.data.id,
          updatedComment: formData
        })
        .then(() => {
          this.$emit('set-edit-mode');
          this.resetPost();
        });
    },

    createNewComment() {
      let formData = new FormData();
      if (this.postContent) {
        formData.append('body', this.postContent);
      }

      this.$store.dispatch('post/creatNewComment', {
        postId: this.postId,
        commentData: formData
      });
      this.resetPost();
    },

    createNewPost() {
      let formData = new FormData();

      if (this.feedwall) {
        formData.append('feedwall', this.feedwall);
      }

      if (this.selectedFile && this.isImageSelected) {
        formData.append('image', this.selectedFile);
      }

      if (this.selectedFile && this.isVideoSelected) {
        formData.append('video', this.selectedFile);
      }

      if (this.selectedFile && this.isOtherSelected) {
        formData.append('file', this.selectedFile);
      }

      if (this.postContent) {
        formData.append('body', this.postContent);
      }

      if (this.linkResponse) {
        formData.append('link_preview_url', this.linkResponse.url);
        formData.append('link_preview_title', this.linkResponse.title);
        formData.append(
          'link_preview_description',
          this.linkResponse.description
        );
        formData.append('link_preview_image_url', this.linkResponse.images[0]);
      }

      this.$store.dispatch('post/createNewPost', formData);
      this.resetPost();
    },

    resetPost() {
      this.setContainerToInitialHeight();
      this.postContent = '';
      if (this.isEditMode) this.$refs.editableRef.innerHTML = '';
      this.showEmojiPicker = false;
      this.selectedFile = null;
      this.showPreview = false;
      this.isImageSelected = false;
      this.srcImagePreview = '';
      this.isVideoSelected = false;
      this.srcSelectedVideo = '';
      this.pastedLink = '';
      this.linkResponse = '';
      this.isLinkSelected = false;
      this.isSending = false;
      this.isFileChanged = false;
      this.isImageChanged = false;
      this.isLinkResponseChanged = false;
      if (this.view === 'post') {
        this.submitBtnText = this.$t('labels.publish');
      } else {
        this.submitBtnText = this.$t('labels.comment');
      }
    },

    getFileNameFromUrl(str) {
      return str
        .split('\\')
        .pop()
        .split('/')
        .pop();
    }
  },

  computed: {
    user() {
      return this.$store.state.auth.user_data;
    },

    feedwall() {
      return this.$store.state.auth.selectedFeedWall;
    }
  },

  watch: {
    postContent: function(value) {
      if (value !== '') {
        this.$refs.refSubmitBtn.disabled = false;
        this.closeBtnDisplayed = true;
      } else {
        this.$refs.refSubmitBtn.disabled = true;
        this.closeBtnDisplayed = false;
      }
    },

    selectedFile: function(value) {
      if (
        value === '' &&
        this.selectedFile === null &&
        this.linkResponse === ''
      ) {
        this.$refs.refSubmitBtn.disabled = true;
      } else {
        this.$refs.refSubmitBtn.disabled = false;
      }
    },

    linkResponse: function(value) {
      if (value === null && this.postContent === '') {
        this.$refs.refSubmitBtn.disabled = true;
      } else {
        this.$refs.refSubmitBtn.disabled = false;
      }
    }
  },

  mounted() {
    if (this.isEditMode) {
      if (this.data.body) {
        this.postContent = this.data.body;
        this.$refs.editableRef.innerHTML = this.postContent;
        this.$refs.editableRef.focus();
      }

      if (this.data.file) {
        this.isOtherSelected = true;
        this.showPreview = true;
        this.selectedFile = this.data.file;
        this.otherFileName = this.getFileNameFromUrl(this.data.file);
      }

      if (this.data.image) {
        this.selectedFile = this.data.image;
        this.srcImagePreview = this.selectedFile;
        this.showPreview = true;
        this.isImageSelected = true;
      }

      if (this.data.video) {
        this.selectedFile = this.data.video;
        this.showPreview = true;
        this.isVideoSelected = true;
        this.srcSelectedVideo = this.selectedFile;
      }

      if (this.data.link_preview) {
        this.isLinkSelected = true;
        this.pastedLink = this.data.link_preview.link_preview_url;
      }

      //this.textAreaFocusHandler();
      this.submitBtnText = this.$t('labels.update');
    } else {
      if (this.view === 'post') {
        this.submitBtnText = this.$t('labels.publish');
      } else {
        this.submitBtnText = this.$t('labels.comment');
      }
    }
  }
};
</script>

<style scoped>
.emoji-btn {
  margin: 10px;
  background-image: url('/assets/images/react.png');
  background-size: cover;
  width: 16px;
  height: 16px;
}

.remove-item-btn {
  background-image: url('/assets/images/icon.png');
  background-size: cover;
  width: 20px;
  height: 20px;
  position: absolute;
  top: -10px;
  right: -10px;
}

.image-video-container {
  position: relative;
  width: fit-content;
}

.other-file-container {
  position: relative;
  width: fit-content;
  border: 1px solid #f3f3f4;
  border-radius: 8px;
  width: 100%;
}

img.image-preview {
  width: 100%;
  max-width: 64px;
  border-radius: 5px;
  cursor: pointer;
}

img.image-preview:hover {
  opacity: 0.7;
}

.error-container {
  padding: 10px;
  color: #e04247;
  font-size: 16px;
  font-weight: 600;
}

.remove-btn {
  position: absolute;
  top: 8px;
  right: 10px;
}

.link-container {
  position: relative;
  margin: 6px;
}

.link-container >>> .wrapper {
  box-shadow: none;
  border: 1px solid #c8cdd3;
}

.link-container >>> .wrapper img {
  width: 100%;
  max-width: 300px;
  max-height: 100px;
  margin-top: 10px;
}

.link-container >>> .wrapper .card-img {
  display: flex;
  justify-content: center;
}

.link-preview {
  position: relative;
}

.paste-link-input {
  background-color: #f3f3f4;
  border-radius: 8px;
  box-sizing: border-box;
  width: 100%;
  border: thin solid #fff;
  outline: none;
  font-size: 14px;
  height: 44px;
  padding: 9px 12px;
  resize: none;
}
.paste-link-input:focus {
  border: thin solid #ffcec1;
  background-color: #fff;
}
.paste-link-input:hover {
  background: #f3f3f4;
}

.post-text-area {
  overflow-y: hidden;
  max-height: 200vh;
  width: 100%;
  resize: none;
  padding: 6px 12px 12px 12px;
  line-height: 1.5;
  box-sizing: border-box;
}

.action-btn-container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
}

.post-btn {
  background-color: #ff7062;
  min-width: 70px;
  padding: 8px 12px;
  font-size: 14px;
  display: inline-block;
  border-width: 1px;
  border-style: solid;
  border-radius: 4px;
  border-color: #ff7062;
  line-height: 1;
  cursor: pointer;
  text-align: center;
  color: #fff;
  height: 40px;
}

.post-btn:disabled {
  opacity: 0.5;
}
</style>
