<template>
  <div>
    <p class="text-concat" v-html="formattedString"></p>
    <span v-show="text.length > maxChars">
      <span
        class="v-close"
        id="readmore"
        v-show="!isReadMore"
        v-on:click="triggerReadMore($event, true)"
        >{{ moreStr }}</span
      >
      <span
        class="v-open"
        id="readmore"
        v-show="isReadMore"
        v-on:click="triggerReadMore($event, false)"
        >{{ lessStr }}</span
      >
    </span>
  </div>
</template>

<script>
export default {
  name: 'TextContainer',

  props: {
    moreStr: String,
    lessStr: String,
    text: String,
    maxChars: Number
  },

  data() {
    return {
      isReadMore: false
    };
  },

  methods: {
    getParsedText(text) {
      const URLMatcher = /(?:(?:https?):\/\/|www\.)(?:\([-A-Z0-9+&@#\\/%=~_|$?!:,.]*\)|[-A-Z0-9+&@#\\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\\/%=~_|$])/gim;
      const withLinks = text.replace(
        URLMatcher,
        match =>
          `<a rel="noopener noreferrer" target="_blank" href="${match}">${match}</a>`
      );
      return withLinks.replace(/\n/g, '<br />');
    },

    triggerReadMore(e, b) {
      if (this.lessStr !== null || this.lessStr !== '') this.isReadMore = b;
    }
  },

  computed: {
    formattedString() {
      let valContainer = this.text;
      if (!this.isReadMore && this.text.length > this.maxChars) {
        valContainer = valContainer.substring(0, this.maxChars) + '...';
      }
      return this.getParsedText(valContainer);
    }
  }
};
</script>
