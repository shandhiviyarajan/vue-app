<template>
  <div class="file-media">
    <div class="image" v-if="media.image">
      <img class="link" :src="media.image" />
    </div>
    <div class="video" v-if="media.video">
      <video controls :src="media.video" class="link"></video>
    </div>
    <div class="file" v-if="media.file">
      <a :href="media.file" download>
        <div class="file-container">
          <i class="fa fa-file"></i>
          <div class="file-name">{{ getFilename(media.file).substr(33) }}</div>
        </div>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FileMedia',

  props: {
    media: Object
  },

  methods: {
    getFilename(url) {
      return url
        .split('/')
        .pop()
        .split('?')[0];
    }
  }
};
</script>
