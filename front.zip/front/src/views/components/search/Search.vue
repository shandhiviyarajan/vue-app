<template>
  <v-form>
    <v-autocomplete
      id="app-header__search"
      v-model="model"
      :items="search_results"
      color="white"
      text
      hide-selected
      append-icon
      prepend-inner-icon="fa fa-search"
      clearable
      hide-no-data
      hide-details
      item-text="title"
      placeholder="Start typing to Search"
      return-object
    >
      <v-list-item slot="prepend-item" slot-scope="{ items }">{{ items.length }} results found</v-list-item>

      <template slot="item" slot-scope="{ item }">
        <v-list-item-content>
          <div v-if="item.type==='user'">
            <div class="user">
              <img src="/assets/images/user.jpg" alt />
              <p>{{ item.title }}</p>
              <span>{{ item.type }}</span>
            </div>
          </div>

          <div v-if="item.type==='post'">
            <div class="post">
              <div class="d-flex justify-space-between align-center">
                <div class="d-flex">
                  <i class="icon-sheet"></i>
                  <p>{{item.title}}</p>
                </div>
                <span>{{ item.type }}</span>
              </div>
              <small>{{item.desc}}</small>
            </div>
          </div>

          <div v-if="item.type==='comment'">
            <div class="comment">
              <div class="d-flex justify-space-between align-center">
                <div class="d-flex">
                  <i class="icon-comment"></i>
                  <p>
                    {{
                    item.title
                    }}
                  </p>
                </div>
                <span>{{ item.type }}</span>
              </div>
              <small>
                {{
                item.date_time
                }}
              </small>
            </div>
          </div>
        </v-list-item-content>
      </template>
    </v-autocomplete>
  </v-form>
</template>

<script>
export default {
  name: 'Search',

  data() {
    return {
      model: null,
      isLoading: false,
      search_results: [
        {
          type: 'user',
          title: 'Shan Dhiviyarajan'
        },
        {
          type: 'comment',
          title: 'Comment Chris a commenté « Listes d’envies »',
          date_time: 'Je vais tester ça !'
        },
        {
          type: 'post',
          title: 'Post Baptiste • French in Japan',
          desc:
            'L’autre fois, j’ai testé ce bistrot japonais, aussi nommé ’Izakaya’, et c’était une bel…'
        }
      ]
    };
  },
  computed: {},

  methods: {}
};
</script>