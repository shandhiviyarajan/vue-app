<template>
  <v-container class="fill-height" fluid>
    <form id="subscription-form">
      <div id="card-element" class="MyCardElement">
        <!-- Elements will create input elements here -->
      </div>

      <!-- We'll put the error messages in this element -->
      <div id="card-errors" role="alert"></div>
      <button type="submit">Subscribe</button>
    </form>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  name: 'Stripe',
  data() {
    return {
      message: ''
    };
  },
  computed: {
    user() {
      return this.$store.state.auth.user_data;
    }
  },

  mounted() {
    this.includeStripe(
      'js.stripe.com/v3/',
      function() {
        this.configureStripe();
      }.bind(this)
    );
  },

  methods: {
    includeStripe(URL, callback) {
      let documentTag = document,
        tag = 'script',
        object = documentTag.createElement(tag),
        scriptTag = documentTag.getElementsByTagName(tag)[0];
      object.src = '//' + URL;
      if (callback) {
        object.addEventListener(
          'load',
          function(e) {
            callback(null, e);
          },
          false
        );
      }
      scriptTag.parentNode.insertBefore(object, scriptTag);
    },
    configureStripe() {
      // eslint-disable-next-line no-undef
      var stripe = Stripe('pk_test_jxHC4OLpaiLtlbTGnKVLRUdx00EorjN7op');
      var elements = stripe.elements();

      var style = {
        base: {
          color: '#32325d',
          fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
          fontSmoothing: 'antialiased',
          fontSize: '16px',
          '::placeholder': {
            color: '#aab7c4'
          }
        },
        invalid: {
          color: '#fa755a',
          iconColor: '#fa755a'
        }
      };

      var cardElement = elements.create('card', { style: style });
      cardElement.mount('#card-element');

      cardElement.addEventListener('change', ({ error }) => {
        const displayError = document.getElementById('card-errors');
        if (error) {
          displayError.textContent = error.message;
        } else {
          displayError.textContent = '';
        }
      });

      const stripePaymentMethodHandler = async result => {
        if (result.error) {
          // Show error in payment form
        } else {
          // Otherwise send paymentMethod.id to your server
          axios.patch(
            'auth/users/' + this.$store.state.auth.user_data.id + '/pay/',
            { payment_id: result.paymentMethod.id },
            {
              headers: {
                Authorization: 'JWT ' + this.user.access
              }
            }
          );
        }
      };

      const form = document.getElementById('subscription-form');

      form.addEventListener('submit', async event => {
        // We don't want to let default form submission happen here,
        // which would refresh the page.
        event.preventDefault();

        const result = await stripe.createPaymentMethod({
          type: 'card',
          card: cardElement,
          billing_details: {
            email: 'max@example.com'
          }
        });

        stripePaymentMethodHandler(result);
      });
    }
  }
};
</script>

<style scoped>
.MyCardElement {
  height: 40px;
  padding: 10px 12px;
  width: 500px;
  color: #32325d;
  background-color: white;
  border: 1px solid transparent;
  border-radius: 4px;

  box-shadow: 0 1px 3px 0 #e6ebf1;
  -webkit-transition: box-shadow 150ms ease;
  transition: box-shadow 150ms ease;
}

.MyCardElement--focus {
  box-shadow: 0 1px 3px 0 #cfd7df;
}

.MyCardElement--invalid {
  border-color: #fa755a;
}

.MyCardElement--webkit-autofill {
  background-color: #fefde5 !important;
}
</style>
