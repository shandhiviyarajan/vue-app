<template>
  <div>
    {{
    recentActivity.user.username.charAt(0).toUpperCase() +
    recentActivity.user.username.slice(1)
    }}
    {{ $t('labels.commented_on_this') }} {{ date }}
  </div>
</template>

<script>
export default {
  name: 'RecentActivity',

  props: {
    recentActivity: Object
  },

  computed: {
    date() {
      let monthNames = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
      ];
      let currentDate = new Date(this.recentActivity.created_at);
      let date = currentDate.getDate();
      let month = currentDate.getMonth(); //Be careful! January is 0 not 1
      let year = currentDate.getFullYear();

      return `${monthNames[month]} ${date}, ${year}`;
    }
  }
};
</script>
