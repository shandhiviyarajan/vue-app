<template>
  <div id="app-register">
    <v-row align="center" justify="center">
      <v-col v-show="registered">
        <v-layout class="alert" justify-center flex-column align-center>
          <div class="alert__img">
            <img src="/assets/svg/success-tick.svg" />
          </div>
          <div class="alert__title">
            <h2>{{ $t('labels.welcome') }} {{ user.username }}</h2>
          </div>
          <div class="alert__body">
            <a class="v-link primary" @click="go_to_login" style="font-size: 17px">
              <small>{{ $t('auth.link_from_registered_to_login') }}</small>
            </a>
          </div>
        </v-layout>
      </v-col>

      <v-col v-show="!registered" cols="12" sm="12" lg="8" xs="12">
        <v-card class="elevation-0">
          <h1 class="text-center mb-6">{{ $t("auth.sign_up") }}</h1>
          <v-form @submit.prevent="handleRegistration" v-model="is_form_valid" ref="form">
            <div class="v-form-element mb-6">
              <label>{{ $t('labels.username') }}</label>
              <v-text-field
                filled
                rounded
                dense
                :rules="username_rules"
                name="username"
                hide-details="auto"
                v-model="user.username"
                required
              />
            </div>
            <div class="v-form-element mb-6">
              <label for>{{ $t('labels.email') }}</label>
              <v-text-field
                filled
                rounded
                dense
                :rules="email_rules"
                name="login"
                hide-details="auto"
                v-model="user.email"
              />
            </div>
            <div class="v-form-element mb-6">
              <label>{{ $t('labels.password') }}</label>
              <v-text-field
                filled
                rounded
                dense
                id="password"
                :rules="password_rules"
                name="password"
                hide-details="auto"
                type="password"
                v-model="user.password"
              />
            </div>
            <div class="v-form-element text-center mb-6">
              <v-btn class="primary" elevation="0" type="submit">{{ $t('buttons.register') }}</v-btn>
            </div>

            <div class="v-form-element mb-6">
              <p class="text-center">
                <a class="v-link primary" @click="go_to_login">
                  <small>{{ $t('auth.link_from_register_to_login') }}</small>
                </a>
              </p>
            </div>
          </v-form>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import User from '../../../models/user';

export default {
  name: 'Register',
  data() {
    return {
      user: new User('', '', ''),
      message: '',
      registered: false,
      username: '',
      is_form_valid: false,
      username_rules: [
        v => !!v || this.$t('validation.required_field'),
        v =>
          v.length <= 100 ||
          this.$t('validation.username_must_not_exceed_100_cars')
      ],
      email_rules: [v => !!v || this.$t('validation.required_field')],
      password_rules: [
        v => !!v || this.$t('validation.required_field'),
        v => v.length > 7 || this.$t('validation.password_is_too_short')
      ]
    };
  },
  computed: {
    loggedIn() {
      return this.$store.state.auth.status.loggedIn;
    }
  },
  created() {
    if (this.loggedIn == 'true') {
      this.$router.push({ name: 'Home' });
    }
  },

  methods: {
    handleRegistration() {
      if (!this.is_form_valid) {
        this.$refs.form.validate();
        return;
      }
      this.$store.dispatch('auth/register', this.user).then(
        () => {
          this.registered = true;
          this.message = 'Welcome, ' + this.user.username + '. ';
        },
        err => {
          if (err.response.data['email']) {
            if (err.response.data['email'] == 'Enter a valid email address.') {
              this.email_rules = this.email_rules.concat([
                v =>
                  /\S+@\S+\.\S+/.test(v) ||
                  this.$t('validation.not_valid_email')
              ]);
            } else if (
              err.response.data['email'] ==
              'A user with that email already exists'
            ) {
              const tried_email = this.user.email;
              this.email_rules = this.email_rules.concat([
                v =>
                  v != tried_email || this.$t('validation.email_already_exists')
              ]);
            }
          }

          if (err.response.data['username']) {
            // This is the only possible error with username
            const tried_username = this.user.username;
            this.username_rules = this.username_rules.concat([
              v =>
                v != tried_username ||
                this.$t('validation.username_already_exists')
            ]);
          }

          if (err.response.data['password']) {
            const tried_password = this.user.password;
            this.password_rules = this.password_rules.concat([
              v =>
                v != tried_password ||
                this.$t('validation.password_not_strong_enough')
            ]);
          }
        }
      );
    },
    go_to_login() {
      this.$router.push({ name: 'Login' });
    }
  }
};
</script>

<style scoped>
.v-application a.mylink {
  /* Best way to override Vuetify default's "".v-application a" */
  text-decoration: none;
  color: #74a6a2;
}

.v-application a.mylink:hover {
  text-decoration: underline;
}
</style>
