<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="8" md="4">
        <h2 class="mb-6">{{ $t('auth.choose_a_new_password') }}</h2>
        <p v-show="message">{{ message }}</p>
        <v-card v-show="!password_reset_validated" class="elevation-12">
          <v-card-text>
            <v-form @submit.prevent="handlePasswordReset">
              <div class="v-form-element">
                <label>{{ $t('auth.new_password') }}</label>
                <v-text-field
                  id="new_password"
                  name="new_password"
                  type="password"
                  v-model="new_password"
                />
              </div>
              <div class="v-form-element">
                <label>{{ $t('auth.confirm_new_password') }}</label>
                <v-text-field
                  id="re_new_password"
                  name="re_new_password"
                  type="password"
                  v-model="re_new_password"
                />
              </div>

              <div class="v-form-element">
                <v-btn color="primary" type="submit">{{ $t('auth.reset_password') }}</v-btn>
              </div>
            </v-form>
          </v-card-text>
          <v-card-actions>
            <v-spacer />
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  name: 'Register',
  data() {
    return {
      new_password: '',
      re_new_password: '',
      message: '',
      uid: '',
      token: '',
      password_reset_validated: false
    };
  },
  created() {
    this.uid = this.$route.query.uid;
    this.token = this.$route.query.token;
  },

  methods: {
    handlePasswordReset() {
      let reset_data = {
        uid: this.uid,
        token: this.token,
        new_password: this.new_password,
        re_new_password: this.re_new_password
      };
      axios.post('auth/users/reset_password_confirm/', reset_data).then(
        () => {
          this.message = this.$t('messages.reseted_password_successfully');
          this.password_reset_validated = true;
        },
        error => {
          this.message = 'Error ' + error.toString();
        }
      );
    },
    go_to_login() {
      this.$router.push({ name: 'Login' });
    }
  }
};
</script>
