<template>
  <v-container class="fill-height m-0 p-0" fluid id="app-login">
    <v-row align="center" justify="center" class="m-0">
      <v-col v-show="state == 'to_login'" cols="12" sm="12" lg="8">
        <h1 class="mb-6">{{$t("auth.sign_in")}}</h1>
        <p v-show="message">{{ message }}</p>
        <v-card elevation="0">
          <!-- <div class="social-logins mb-8">
            <v-btn class="google-sign-in" elevation="0">
              <i class="fa fa-google"></i>
              {{ $t('buttons.google') }}
            </v-btn>

            <v-btn icon class="twitter-sign-in" elevation="0">
              <i class="fa fa-twitter"></i>
            </v-btn>
          </div>-->
          <!-- <div class="divider mb-8">
            <span>Ou</span>
          </div>-->
          <v-form @submit.prevent="handleLogin" v-model="is_login_form_valid" ref="login_form">
            <div class="v-form-element mb-6">
              <label class="mb-2">{{ $t('labels.email') }}</label>
              <v-text-field
                filled
                rounded
                dense
                :error-messages="email_error_messages"
                :rules="email_rules"
                name="login"
                type="text"
                autofocus
                v-model="user.email"
              />
            </div>

            <div class="v-form-element mb-6">
              <label class="mb-2">{{ $t('labels.password') }}</label>
              <v-text-field
                filled
                rounded
                dense
                name="password"
                id="password"
                :append-icon="show_password ? 'mdi-eye' : 'mdi-eye-off'"
                :error-messages="password_error_messages"
                :rules="password_rules"
                :type="show_password ? 'text' : 'password'"
                v-model="user.password"
                @click:append="show_password = !show_password"
              />
            </div>
            <div class="v-form-element mb-6">
              <a
                class="v-link secondary forget-password-link"
                @click="forgetPassword"
              >{{ $t('auth.link_to_go_forgot_password_page') }}</a>
            </div>

            <div class="v-form-element text-center mb-6">
              <v-btn
                :loading="loading_bar"
                class="primary"
                elevation="0"
                type="submit"
              >{{ $t('buttons.login') }}</v-btn>
            </div>

            <div class="v-form-element my-6">
              <p class="text-center">
                <small>{{ $t('labels.account') }}</small>
                <a
                  class="v-link primary register-link"
                  href="/#/register"
                >{{ $t('buttons.register') }}</a>
              </p>
            </div>
          </v-form>
        </v-card>
      </v-col>
      <!-- forgot password-->
      <v-col v-show="state =='to_resend_email'" sm="8" md="8" lg="8" xs="12">
        <v-card class="elevation-0">
          <h1 class="mb-6">{{ $t('labels.forgot_password') }}</h1>
          <p>{{ $t('labels.forgot_password_sub') }}</p>
          <v-form
            @submit.prevent="sendMailPassword"
            v-model="is_forgot_email_form_valid"
            ref="forgot_email_form"
          >
            <div class="v-form-element mb-6">
              <label class="mb-2">{{ $t('labels.email') }}</label>
              <v-text-field
                filled
                rounded
                dense
                placeholder="Email address"
                :rules="forgot_email_rules"
                name="email"
                v-model="forgot_email"
              />
            </div>

            <div class="v-form-element mb-6">
              <v-btn
                class="primary"
                elevation="0"
                :loading="loading_bar"
                type="submit"
              >{{ $t('buttons.send_mail_to_reset_password') }}</v-btn>
            </div>

            <div class="v-form-element my-6">
              <p class="text-center">
                <small>{{ $t('labels.account') }} &nbsp;</small>
                <a class="v-link primary" @click="backToLogin">
                  <small>{{ $t('auth.link_from_forgot_password_to_login') }}</small>
                </a>
              </p>
            </div>
          </v-form>
        </v-card>
      </v-col>

      <v-col cols="6" v-show="state == 'email_sent'">
        <Alert :title="email_sent_message" />
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import Alert from '../common/Alert';
import User from '../../../models/user';
import axios from 'axios';

export default {
  name: 'Login',
  components: {
    Alert
  },
  data() {
    return {
      loading_bar: false,
      show_password: 0,
      user: new User('', '', ''),
      message: '',
      email_sent_message: '',
      state: 'to_login',
      email_error_messages: '',
      password_error_messages: '',
      is_login_form_valid: false,
      email_rules: [v => !!v || this.$t('validation.required_field')],
      password_rules: [v => !!v || this.$t('validation.required_field')],
      is_forgot_email_form_valid: false,
      forgot_email: '',
      forgot_email_rules: [v => !!v || this.$t('validation.required_field')]
    };
  },
  computed: {
    loggedIn() {
      return this.$store.state.auth.status.loggedIn;
    }
  },
  created() {
    if (this.loggedIn == 'true') {
      this.$router.push({ name: 'Home' });
    }
  },

  methods: {
    handleLogin() {
      //activate loading
      this.loading_bar = true;

      if (!this.is_login_form_valid) {
        this.loading_bar = false;
        this.$refs.login_form.validate();
        return;
      }
      this.$store.dispatch('auth/login', this.user).then(
        response => {
          if (response.is_active) {
            this.$router.push({ name: 'Home' });
            this.loading_bar = false;
          } else {
            this.$router.push({ name: 'Stripe' });
          }
        },
        err => {
          this.loading_bar = false;
          if (err.response.data.detail == 'No account has this email') {
            const tried_email = this.user.email;
            this.email_rules = this.email_rules.concat([
              v =>
                /\S+@\S+\.\S+/.test(v) || this.$t('validation.not_valid_email'),
              v => v != tried_email || this.$t('validation.unknown_email')
            ]);
          }
          if (err.response.data.detail == 'Password does not match email') {
            const tried_password = this.user.password;
            this.password_rules = this.password_rules.concat([
              v =>
                v != tried_password ||
                this.$t('validation.password_does_not_match_email')
            ]);
          }
        }
      );
    },
    forgetPassword() {
      this.state = 'to_resend_email';
    },
    backToLogin() {
      this.state = 'to_login';
    },
    sendMailPassword() {
      this.loading_bar = true;
      if (!this.is_forgot_email_form_valid) {
        this.loading_bar = false;
        this.$refs.forgot_email_form.validate();
        return;
      }
      axios
        .post('auth/users/reset_password/', {
          email: this.forgot_email,
          origin: window.location.origin
        })
        .then(
          () => {
            this.loading_bar = false;
            this.email_sent_message = this.$t(
              'auth.confirmation_email_with_reset_password_link_sent'
            );
            this.state = 'email_sent';
          },
          err => {
            this.loading_bar = false;
            if (err.response.data['email']) {
              if (
                err.response.data['email'] == 'Enter a valid email address.'
              ) {
                this.forgot_email_rules = this.forgot_email_rules.concat([
                  v =>
                    /\S+@\S+\.\S+/.test(v) ||
                    this.$t('validation.not_valid_email')
                ]);
              } else if (
                err.response.data['email'] == 'No account has this email'
              ) {
                const tried_email = this.forgot_email;
                this.forgot_email_rules = this.forgot_email_rules.concat([
                  v => v != tried_email || this.$t('validation.unknown_email')
                ]);
              }
            }
          }
        );
    }
  }
};
</script>


