import Vue from 'vue';
Vue.config.productionTip = true; /* to be changed toward false */
Vue.config.devtools = true;
import App from './App.vue';
import router from './router';
import store from './store';
import vuetify from './plugins/vuetify';
import i18n from './i18n';
import axios from 'axios';
import VueNativeSock from 'vue-native-websocket';
import VTooltip from 'v-tooltip';
import VueChatScroll from 'vue-chat-scroll';

axios.defaults.baseURL = process.env.VUE_APP_URL;

import interceptorsSetup from './interceptors';
interceptorsSetup();

Vue.use(VueNativeSock, '_', {
  connectManually: true,
  store: store,
  format: 'json'
});

Vue.use(VTooltip);

Vue.use(VueChatScroll);

new Vue({
  router,
  store,
  vuetify,
  i18n,

  render: h => h(App)
}).$mount('#app');