import PostService from '../services/post.service';

const initialState = {
  posts: [],
  pageCount: 1,
  haveNextPage: false
};

export const post = {
  namespaced: true,
  state: initialState,
  actions: {
    getPostList({ commit }) {
      PostService.getPost().then(response => {
        commit('successPost', response.data);
      });
    },

    createNewPost({ commit }, post) {
      PostService.createPost(post).then(response => {
        commit('postCreateSuccess', response);
      });
    },

    updatePost({ commit }, payload) {
      return PostService.updatePost(payload).then(response => {
        commit('postUpdateSuccess', response);
      });
    },

    deletePost({ commit }, postId) {
      PostService.deletePost(postId).then(() => {
        commit('postDeleteSuccess', postId);
      });
    },

    creatNewComment({ commit }, payload) {
      PostService.createComment(payload).then(response => {
        commit('commentCreateSuccess', response);
      });
    },

    updateComment({ commit }, payload) {
      return PostService.updateComment(payload).then(response => {
        commit('commentUpdatedSuccess', response);
      });
    },

    loadPreviousComments({ commit }, payload) {
      PostService.loadPreviousComments(payload).then(response => {
        commit('previousCommentsLoadSuccess', response);
      });
    },

    deleteComment({ commit }, payload) {
      const { commentId } = payload;
      PostService.deleteComment(commentId).then(() => {
        commit('deleteCommentSuccess', payload);
      });
    },

    addLikeToPost({ commit }, postId) {
      PostService.addLikeToPost(postId).then(response => {
        commit('postLikeSuccess', response);
      });
    },

    deleteLikeFromPost({ commit }, payload) {
      const { likeId, postId } = payload;
      PostService.deleteLikeFromPost(likeId).then(() => {
        commit('postLikeDeleteSuccess', postId);
      });
    },

    addLikeToComment({ commit }, payload) {
      const { commentId, postId } = payload;
      PostService.addLikeToComment(commentId).then(response => {
        commit('commentLikeSuccess', { response, postId });
      });
    },

    deleteLikeFromComment({ commit }, payload) {
      const { likeId, postId, commentId } = payload;
      PostService.deleteLikeFromComment(likeId).then(() => {
        commit('commentLikeDeleteSuccess', { commentId, postId });
      });
    }
  },
  mutations: {
    setInitialState(state) {
      state.posts = [];
      state.pageCount = 1;
      state.haveNextPage = false;
    },

    successPost(state, post) {
      state.posts = [...state.posts, ...post.results];
      if (post.next) {
        state.haveNextPage = true;
        state.pageCount = parseInt(post.next.slice(post.next.length - 1));
      } else {
        state.haveNextPage = false;
      }
    },

    postCreateSuccess(state, response) {
      state.posts = [response.data, ...state.posts];
    },

    postUpdateSuccess(state, response) {
      state.posts.map(post => {
        if (post.id === response.data.id) {
          Object.assign(post, response.data);
        }
      });
    },

    postDeleteSuccess(state, response) {
      state.posts = state.posts.filter(post => {
        return post.id !== response;
      });
    },

    commentCreateSuccess(state, response) {
      state.posts.map(post => {
        if (post.id === response.data.parent) {
          post.comments.results.push(response.data);
        }
      });
    },

    commentUpdatedSuccess(state, response) {
      state.posts.map(post => {
        if (post.id === response.data.parent) {
          post.comments.results.map(comment => {
            if (comment.id === response.data.id) {
              Object.assign(comment, response.data);
            }
          });
        }
      });
    },

    previousCommentsLoadSuccess(state, response) {
      if (response.data !== null) {
        state.posts.map(post => {
          if (post.id === response.data.results[0].parent) {
            post.comments.next = response.data.next;
            post.comments.previous = response.data.previous;
            post.comments.results = [
              ...response.data.results.reverse(),
              ...post.comments.results
            ];
          }
        });
      }
    },

    deleteCommentSuccess(state, payload) {
      const { postId, commentId } = payload;
      state.posts.map(post => {
        if (post.id === postId) {
          post.comments.results = post.comments.results.filter(comment => {
            return comment.id !== commentId;
          });
        }
      });
    },

    postLikeDeleteSuccess(state, postId) {
      state.posts.map(post => {
        if (post.id === postId) {
          post.likes.user_liked = false;
          post.likes.likes_count--;
        }
      });
    },

    postLikeSuccess(state, response) {
      state.posts.map(post => {
        if (post.id === response.data.postComment) {
          post.likes.user_like_id = response.data.id;
          post.likes.user_liked = true;
          post.likes.likes_count++;
        }
      });
    },

    commentLikeSuccess(state, payload) {
      const { response, postId } = payload;
      state.posts.map(post => {
        if (post.id === postId) {
          post.comments.results.map(comment => {
            if (comment.id === response.data.postComment) {
              comment.likes.user_like_id = response.data.id;
              comment.likes.user_liked = true;
              comment.likes.likes_count++;
            }
          });
        }
      });
    },

    commentLikeDeleteSuccess(state, payload) {
      const { postId, commentId } = payload;
      state.posts.map(post => {
        if (post.id === postId) {
          post.comments.results.map(comment => {
            if (comment.id === commentId) {
              comment.likes.user_liked = false;
              comment.likes.likes_count--;
            }
          });
        }
      });
    }
  }
};
