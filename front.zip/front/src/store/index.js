import Vue from 'vue';
import Vuex from 'vuex';

import { auth } from './auth.module';
import { chat } from './chat.module';
import { post } from './post.module';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {},
  mutations: {
    SOCKET_ONOPEN(state, event) {
      state.chat.isConnected = true;
    },
    SOCKET_ONCLOSE(state, event) {
      state.chat.isConnected = false;
    },
    SOCKET_ONMESSAGE (state, message)  {
      console.log('message',message);
    },
    SOCKET_ONERROR(state, event) {
      console.log('SOCKET_ONERROR', event);
    },
    SOCKET_RECONNECT(state, count) {
      console.info(state, count)
    },
    SOCKET_RECONNECT_ERROR(state) {
      state.socket.reconnectError = true;
    }
  },
  actions: {},
  modules: {
    auth,
    chat,
    post
  }
});
