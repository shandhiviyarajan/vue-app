import AuthService from '../services/auth.service';

const user_data = JSON.parse(localStorage.getItem('user_data'));
const initialState = user_data
  ? {
      status: { loggedIn: true },
      user_data,
      commu: {
        channels: null,
        feedwalls: null,
        is_free: null,
        name: null,
        bio: null,
        logo: null,
        default_pp: null,
        default_pp_xs: null
      },
      selectedFeedWall: 1
    }
  : {
      status: { loggedIn: false },
      user_data: null,
      commu: {
        channels: null,
        feedwalls: null,
        is_free: null,
        name: null,
        bio: null,
        logo: null,
        default_pp: null,
        default_pp_xs: null
      },
      selectedFeedWall: 1
    };

export const auth = {
  namespaced: true,
  state: initialState,
  actions: {
    pullCommuAndUser({ commit, state }) {
      if (state.status.loggedIn == true) {
        AuthService.pullUser().then(response => {
          commit('pullUserSuccess', response.data);
          AuthService.pullCommu().then(response => {
            commit('pullCommuSuccess', response.data);
          });
        });
      } else {
        AuthService.pullCommu().then(response => {
          commit('pullCommuSuccess', response.data);
        });
      }
    },

    login({ commit }, user) {
      return AuthService.login(user)
        .then(
          response => {
            commit('tokenRequested', response.data);
            localStorage.setItem('user_data', JSON.stringify(response.data));
            return AuthService.pullUser();
          },
          error => {
            commit('loginFailure');
            localStorage.removeItem('user_data');
            return Promise.reject(error);
          }
        )
        .then(
          response => {
            if (response.data?.is_allowed == false) {
              commit('loginSuccessNotAllowed', response.data);
            } else {
              commit('loginSuccessAllowed', response.data);
            }
            commit('pullUserSuccess', response.data);
            return Promise.resolve(response.data);
          },
          err => {
            return Promise.reject(err);
          }
        );
    },

    logout({ commit }) {
      commit('logout');
      localStorage.removeItem('user_data');
    },

    register({ commit }, user) {
      return AuthService.register(user).then(
        response => {
          if (response.data.is_allowed) {
            commit('registerSuccessAllowed');
          } else {
            commit('registerSuccessNotAllowed', response.data);
          }
          return Promise.resolve(response.data);
        },
        error => {
          commit('registerFailure');
          return Promise.reject(error);
        }
      );
    }
  },
  mutations: {
    pullCommuSuccess(state, commu_data) {
      const channels = commu_data.channels;
      delete commu_data.channels;
      if (!state.user_data?.pp) {
        //state.user_data = { pp: commu_data.default_pp };
      }
      state.commu = commu_data;
      this.state.chat.channels = channels;
    },
    pullUserSuccess(state, token_data) {
      if (!token_data?.pp) {
        token_data.pp = state.commu.default_pp;
        token_data.pp_xs = state.commu.default_pp_xs;
      }
      state.user_data = { ...state.user_data, ...token_data };
      this._vm.$connect(process.env.VUE_APP_SOCKET_PATH + state.user_data.access)
    },
    tokenRequested(state, user_data) {
      state.user_data = { ...state.user_data, ...user_data };
    },
    loginSuccessAllowed(state, user_data) {
      state.status.loggedIn = true;
      state.user_data = { ...state.user_data, ...user_data };
    },
    loginSuccessNotAllowed(state, user_data) {
      state.status.loggedIn = 'stripe';
      state.user_data = { ...state.user_data, ...user_data };
    },
    loginFailure(state) {
      state.status.loggedIn = false;
      state.user_data = null;
    },
    logout(state) {
      state.status.loggedIn = false;
      state.user_data = null;
      this._vm.$disconnect();
    },
    registerSuccessActive(state) {
      state.status.loggedIn = false;
      state.user_data = null;
    },
    registerSuccessNotAllowed(state, user_data) {
      state.status.loggedIn = 'stripe';
      state.user_data = user_data;
    },
    registerFailure(state) {
      state.status.loggedIn = false;
    },
    setSelectedFeedWall(state, selectedFeedWall) {
      state.selectedFeedWall = selectedFeedWall;
    }
  },
  getters: {
    loggedIn: state => {
      return state.loggedIn;
    }
  }
};
