import ChatService from '../services/chat.service';
import store from '../store';

const initialState = {
  isConnected: false,
  current_channel_id: 1,
  selectedChannelName: '',
  selectedChannelId: null,
  chatList: [],
  pageCount: 1,
  haveNextPage: false,
  channels: []
};

export const chat = {
  namespaced: true,
  state: initialState,
  actions: {
    chat_create_message(context, message) {
      const { channel_id, message_id } = message;
      if (channel_id == context.state.selectedChannelId) {
        let channel = {
          id: channel_id,
          name: context.state.selectedChannelName
        };
        message.channel = channel;
        message.author = store.state.auth.user_data;
        message.id = message_id;
        context.state.chatList = [...context.state.chatList, message];
      }
    },

    chat_edit_message(context, message) {
      const { message_id, channel_id, body } = message;
      context.state.chatList.map(chat => {
        if (chat.id === message_id && chat.channel.id === channel_id) {
          chat.body = body;
        }
      });
    },

    chat_delete_message(context, message) {
      context.state.chatList = context.state.chatList.filter(chat => {
        return chat.id !== message.message_id;
      });
    },

    getChatList({ commit }) {
      ChatService.getChats().then(response => {
        commit('chatListSuccess', response.data);
      });
    }
  },
  mutations: {
    setInitialState(state) {
      state.chatList = [];
      state.pageCount = 1;
      state.haveNextPage = false;
    },
    setSelectedChannelName(state, selectedChannelName) {
      state.selectedChannelName = selectedChannelName;
    },

    setSelectedChannelId(state, selectedChannelId) {
      state.selectedChannelId = selectedChannelId;
    },

    chatListSuccess(state, response) {
      state.chatList = [...response.results.reverse(), ...state.chatList];
      if (response.next) {
        state.haveNextPage = true;
        state.pageCount = parseInt(
          response.next.slice(response.next.length - 1)
        );
      } else {
        state.haveNextPage = false;
      }
    }
  }
};
