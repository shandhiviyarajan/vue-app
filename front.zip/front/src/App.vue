<template>
  <v-app>
    <Header />
    <v-container>
      <v-row no-gutters>
        <v-col cols="12" lg="3" md="3" class="fixed-top">
          <Aside
            :class="show_side_bar ? '' : 'show'"
            v-on:set-feedwall-id="setSelectedFeedWall"
            :feedWallItems="feedwalls"
            v-if="loggedIn"
          />
        </v-col>
        <v-col cols="12" lg="6" md="6" class="move-left">
          <div class="router-view">
            <!-- router view-->
            <transition name="fade">
              <router-view />
            </transition>
            <!-- router view-->
          </div>
        </v-col>
        <v-col cols="12" lg="3" md="3">
          <Members />
        </v-col>
      </v-row>
    </v-container>
  </v-app>
</template>

<script>
import Aside from './views/components/common/Aside';
import Header from './views/components/common/Header';
import Members from './views/components/members/Members';

export default {
  name: 'App',

  components: {
    Aside,
    Header,
    Members
  },

  data: () => ({
    drawer: false,
    nav_drawer_index: '0',
    user_data: {},
    feedWallId: 1,
    show_side_bar: false,
    bodymovin: {}
  }),

  computed: {
    loggedIn: function() {
      return this.$store.state.auth.status.loggedIn;
    },
    logo: function() {
      return this.$store.state.auth.commu.logo;
    },
    pp: function() {
      return this.$store.state.auth.user_data?.pp;
    },
    getUser: function() {
      return this.$store.state.auth.user_data;
    },
    feedwalls() {
      return this.$store.state.auth.commu.feedwalls;
    },
    getUserText() {
      return (this.$store.state.auth.user_data.username || '')
        .split('')[0]
        .toUpperCase();
    }
  },
  mounted() {
    this.$store.dispatch('auth/pullCommuAndUser');
  },
  methods: {
    setSelectedFeedWall($event) {
      this.feedWallId = $event;
    },

    go_to_feedwall() {
      // if (this.nav_drawer_index != 0) {
      //   this.$router.push({ name: 'Home' });
      // }
      this.$router.push({ name: 'Home' });
    },
    go_to_about() {
      // if (this.nav_drawer_index != 1) {
      //   this.$router.push({ name: 'About' });
      // }
      this.$router.push({ name: 'About' });
    },
    go_to_account() {
      // if (this.nav_drawer_index != 2) {
      //   this.nav_drawer_index = 2;
      //   this.$router.push({ name: 'UserPage' });
      // }
      this.$router.push({ name: 'UserPage' });
    },
    go_to_profile() {
      if (this.$route.name != 'UserProfile')
        this.$router.push({ name: 'UserProfile' });
    }
  }
};
</script>

<style lang="sass">
@import './styles/app.scss'
</style>
