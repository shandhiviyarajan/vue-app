import axios from 'axios';
import store from './store';
import router from './router';

function refreshToken(store) {
  const refreshingCall = axios
    .post('auth/jwt/refresh/', {
      refresh: store.state.auth.user_data.refresh
    })
    .then(
      ({ data: { access } }) => {
        store.state.auth.user_data.access = access;

        return Promise.resolve(true);
      },
      error => {
        store.commit('auth/logout', true);
        router.push({ name: 'Login' });
        return Promise.resolve(true);
      }
    );
  return refreshingCall;
}

export default function setup() {
  axios.interceptors.response.use(
    response => {
      return Promise.resolve(response);
    },
    error => {
      if (error.response.status && error.response.status == 401) {
        if (
          error?.response?.data?.messages &&
          error?.response?.data?.messages[0]?.token_type == 'access'
        ) {
          return refreshToken(store).then(_ => {
            if (store.state.auth.user_data) {
              error.config.headers['Authorization'] =
                'JWT ' + store.state.auth.user_data.access;
              return axios.request(error.config);
            } else {
              return Promise.resolve({
                data: {}
              });
            }
          });
        }
        
      }
      return Promise.reject(error);
    }
  );
}
