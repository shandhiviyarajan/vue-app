import Vue from "vue";
import VueRouter from "vue-router";
import Home from '../views/Home';
import Login from "../views/components/auth/Login";
import Register from "../views/components/auth/Register.vue";
import About from '../views/components/pages/About';
import UserPage from "../views/components/profile/UserPage.vue";
import UserProfile from "../views/components/profile/UserProfile.vue";
import PasswordReset from "../views/components/auth/PasswordReset.vue";
import NotificationPage from "../views/components/NotificationPage";
import MessagesPage from "../views/components/MessagesPage";
import Stripe from "../views/components/stripe/Stripe";
import store from "../store";

import Chat from '../views/components/chat/Chat';

Vue.use(VueRouter);

const routes = [{
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/login",
    name: "Login",
    component: Login,
  },
  {
    path: "/register",
    name: "Register",
    component: Register,
  },
  {
    path: "/stripe",
    name: "Stripe",
    component: Stripe,
  },
  {
    path: "/reset_password",
    name: "PasswordReset",
    component: PasswordReset,
  },
  {
    path: "/about",
    name: "About",
    component: About,
  },
  {
    path: "/account",
    name: "UserPage",
    component: UserPage,
  },
  {
    path: "/profile",
    name: "UserProfile",
    component: UserProfile,
  },
  {
    path: '/chat',
    name: 'Chat',
    component: Chat
  },

  {
    path: '/notifications',
    name: 'NotificationPage',
    component: NotificationPage
  },
  {
    path: '/messages',
    name: 'MessagesPage',
    component: MessagesPage
  }

];

const router = new VueRouter({
  routes,
});

router.beforeEach((to, from, next) => {
  const loggedIn = store.state.auth.status.loggedIn;
  const AVAILABLE_PAGES_WITHOUT_LOGIN = ["Login", "Register", "PasswordReset", "UserPage"];

  if (loggedIn == false && !AVAILABLE_PAGES_WITHOUT_LOGIN.includes(to.name)) {
    next({
      name: "Login"
    });
  } else if (loggedIn == "stripe" && to.name != "Stripe") {
    next({
      name: "Stripe"
    });
  } else {
    next();
  }
});



export default router;